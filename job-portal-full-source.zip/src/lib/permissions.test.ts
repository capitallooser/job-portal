import { describe, expect, it } from 'vitest'
import { can } from './permissions'

describe('can', () => {
  it('allows super admin to manage roles', () => expect(can('super_admin', 'roles.manage')).toBe(true))
  it('denies candidate job publishing', () => expect(can('candidate', 'jobs.publish')).toBe(false))
  it('allows admin candidate approval', () => expect(can('admin', 'users.approve')).toBe(true))
  it('limits associates to job creation by default', () => {
    expect(can('associate', 'jobs.create')).toBe(true)
    expect(can('associate', 'jobs.manage_all')).toBe(false)
  })
})
