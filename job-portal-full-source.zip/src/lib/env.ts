import { z } from 'zod'

const isTest = import.meta.env.MODE === 'test'
const schema = z.object({
  VITE_SUPABASE_URL: z.string().url(),
  VITE_SUPABASE_ANON_KEY: z.string().min(1),
  VITE_APP_NAME: z.string().min(1).default('TalentBridge'),
})

export const env = schema.parse({
  VITE_SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL || (isTest ? 'http://127.0.0.1:54321' : ''),
  VITE_SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY || (isTest ? 'test-anon-key' : ''),
  VITE_APP_NAME: import.meta.env.VITE_APP_NAME || 'TalentBridge',
})
