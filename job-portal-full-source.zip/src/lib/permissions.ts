import type { AppRole } from '../types/domain'

export type Permission =
  | 'roles.manage' | 'users.approve' | 'jobs.create' | 'jobs.publish'
  | 'jobs.manage_all' | 'applications.manage' | 'audit.read' | 'taxonomy.manage'
  | 'settings.manage'

const map: Record<AppRole, ReadonlySet<Permission>> = {
  super_admin: new Set(['roles.manage','users.approve','jobs.create','jobs.publish','jobs.manage_all','applications.manage','audit.read','taxonomy.manage','settings.manage']),
  admin: new Set(['users.approve','jobs.create','jobs.publish','jobs.manage_all','applications.manage','audit.read','taxonomy.manage']),
  associate: new Set(['jobs.create']),
  candidate: new Set(),
}

export function can(role: AppRole, permission: Permission) {
  return map[role].has(permission)
}
