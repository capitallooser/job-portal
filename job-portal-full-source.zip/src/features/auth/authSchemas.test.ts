import { describe, expect, it } from 'vitest'
import { loginSchema, signupSchema } from './authSchemas'

describe('auth schemas', () => {
  it('requires name, valid email, mobile, and a strong password', () => {
    expect(signupSchema.safeParse({ fullName: '', email: 'x', mobile: '', password: '123' }).success).toBe(false)
  })
  it('accepts a valid candidate signup', () => {
    expect(signupSchema.safeParse({ fullName: 'A User', email: 'a@example.com', mobile: '9876543210', password: 'StrongPass1' }).success).toBe(true)
  })
  it('rejects invalid login email', () => {
    expect(loginSchema.safeParse({ email: 'bad', password: 'StrongPass1' }).success).toBe(false)
  })
})
