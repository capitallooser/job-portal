import { z } from 'zod'

export const signupSchema = z.object({
  fullName: z.string().trim().min(2, 'Name is required').max(120),
  email: z.string().trim().email('Enter a valid email'),
  mobile: z.string().trim().regex(/^\+?[0-9 ()-]{8,20}$/, 'Enter a valid mobile number'),
  password: z.string().min(8, 'Use at least 8 characters').max(128)
    .regex(/[A-Za-z]/, 'Include a letter').regex(/[0-9]/, 'Include a number'),
})
export const loginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(1, 'Password is required'),
})
export type SignupInput = z.infer<typeof signupSchema>
export type LoginInput = z.infer<typeof loginSchema>
