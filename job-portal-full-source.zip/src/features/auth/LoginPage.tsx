import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Link, useNavigate } from 'react-router-dom'
import { signIn } from './authApi'
import { loginSchema, type LoginInput } from './authSchemas'
import { fetchSessionProfile } from './useSessionProfile'

export function LoginPage() {
  const navigate = useNavigate(); const [serverError, setServerError] = useState('')
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginInput>({ resolver: zodResolver(loginSchema) })
  return <section className="auth-card"><div className="brand-mark">TB</div><p className="eyebrow">Welcome back</p><h1>Sign in</h1><p className="muted">Use the email connected to your portal account.</p>
    <form className="stack" onSubmit={handleSubmit(async (values) => { try { setServerError(''); await signIn(values); const p=await fetchSessionProfile(); if (!p) return; if (p.is_blocked || p.approval_status !== 'approved') navigate('/pending-approval'); else navigate(p.role === 'candidate' ? '/jobs' : '/admin') } catch(e){ setServerError(e instanceof Error?e.message:'Login failed') } })}>
      <label>Email<input type="email" {...register('email')} autoComplete="email" />{errors.email && <span className="field-error">{errors.email.message}</span>}</label>
      <label>Password<input type="password" {...register('password')} autoComplete="current-password" />{errors.password && <span className="field-error">{errors.password.message}</span>}</label>
      {serverError && <div className="alert error">{serverError}</div>}
      <button className="btn primary" disabled={isSubmitting}>{isSubmitting?'Signing in…':'Sign in'}</button>
    </form><div className="auth-links"><Link to="/forgot-password">Forgot password?</Link><Link to="/signup">Request membership</Link></div>
  </section>
}
