import { render, screen } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'
import { UserApprovalsPage } from './UserApprovalsPage'

vi.mock('./usersApi', () => ({ listUsers: vi.fn().mockResolvedValue([]), approveUser: vi.fn() }))

describe('UserApprovalsPage', () => {
  it('renders candidate approval controls and search', async () => {
    render(<UserApprovalsPage />)
    expect(await screen.findByRole('heading', { name: /user approvals/i })).toBeInTheDocument()
    expect(screen.getByPlaceholderText(/search name, email or mobile/i)).toBeInTheDocument()
  })
})
