import{ supabase }from'../../lib/supabase';export async function getDashboardMetrics(){const{data,error}=await supabase.rpc('admin_dashboard_metrics');if(error)throw error;return data as any}
