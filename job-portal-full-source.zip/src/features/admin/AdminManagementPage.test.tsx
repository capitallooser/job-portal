import { render, screen } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'
import { AdminManagementPage } from './AdminManagementPage'

vi.mock('./adminApi', () => ({
  listBackofficeUsers: vi.fn().mockResolvedValue([]),
  listInvitations: vi.fn().mockResolvedValue([]),
  inviteBackofficeUser: vi.fn(), changeUserRole: vi.fn(),
}))

describe('AdminManagementPage', () => {
  it('renders an email-based back-office invite form', async () => {
    render(<AdminManagementPage />)
    expect(await screen.findByRole('heading', { name: /admin management/i })).toBeInTheDocument()
    expect(screen.getByLabelText(/email/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /send invitation/i })).toBeInTheDocument()
  })
})
