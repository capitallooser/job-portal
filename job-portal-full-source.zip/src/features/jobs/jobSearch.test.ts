import { describe, expect, it } from 'vitest'; import { normalizeSearchFilters } from './jobSearch'
describe('job search filters',()=>{it('trims and removes empty filters',()=>expect(normalizeSearchFilters({keyword:' snowflake ',locations:[],postedWithinDays:0})).toEqual({keyword:'snowflake'}))})
