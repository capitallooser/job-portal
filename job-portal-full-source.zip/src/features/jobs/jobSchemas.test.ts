import { describe, expect, it } from 'vitest'
import { jobDraftSchema } from './jobSchemas'
const base={title:'Data Engineer',companyName:null,clientName:null,categoryId:null,shortSummary:'',description:'A detailed role description long enough for validation.',durationText:null,durationMonths:null,experienceMinYears:null,experienceMaxYears:null,employmentType:'contract',workMode:'remote',salaryText:null,locations:[],mandatorySkills:[],preferredSkills:[],keywords:[],closesAt:null} as const
describe('jobDraftSchema',()=>{
  it('requires a title',()=>expect(jobDraftSchema.safeParse({...base,title:''}).success).toBe(false))
  it('rejects reversed experience',()=>expect(jobDraftSchema.safeParse({...base,experienceMinYears:9,experienceMaxYears:7}).success).toBe(false))
  it('requires a location for hybrid jobs',()=>expect(jobDraftSchema.safeParse({...base,workMode:'hybrid'}).success).toBe(false))
  it('allows blank salary and ambiguous optional fields in drafts',()=>expect(jobDraftSchema.safeParse(base).success).toBe(true))
})
