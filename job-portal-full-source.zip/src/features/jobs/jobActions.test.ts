import { describe, expect, it } from 'vitest'; import { lifecycleActionLabel } from './jobActions'
describe('job action labels',()=>{it('uses readable lifecycle labels',()=>expect(lifecycleActionLabel('closed')).toBe('Close job'))})
