import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { App } from './App'

describe('App', () => {
  it('renders the portal shell', () => {
    render(<App />)
    expect(screen.getByText(/job portal/i)).toBeInTheDocument()
  })
})
