export function Skeleton({height=18}:{height?:number}){return <div aria-hidden="true" style={{height,borderRadius:8,background:'#eef0f3',animation:'pulse 1.4s ease-in-out infinite'}}/>}
