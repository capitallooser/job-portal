export type AppRole = 'super_admin' | 'admin' | 'associate' | 'candidate'
export type ApprovalStatus = 'pending_approval' | 'approved' | 'rejected'
export type JobStatus = 'draft' | 'pending_review' | 'published' | 'closed' | 'archived'
export type WorkMode = 'remote' | 'hybrid' | 'onsite'
export type EmploymentType = 'permanent' | 'contract' | 'internship' | 'freelance' | 'part_time'
export type InterestStatus =
  | 'interested' | 'profile_reviewed' | 'profile_shared' | 'shortlisted'
  | 'interview' | 'selected' | 'rejected' | 'on_hold' | 'closed' | 'withdrawn'

export interface Profile {
  id: string
  full_name: string
  email: string
  mobile: string | null
  approval_status: ApprovalStatus
  is_blocked: boolean
  approved_at: string | null
  created_at: string
}

export interface SessionProfile extends Profile { role: AppRole }
