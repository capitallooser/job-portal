-- JOB PORTAL BOOTSTRAP V2 FIXED
-- Fix marker: no comma before CROSS JOIN in admin_dashboard_metrics

-- TalentBridge hosted Supabase bootstrap
-- Run this ONCE in Supabase Dashboard -> SQL Editor -> New query.
-- It installs schema, security policies, functions and starter taxonomy.

-- ============================================================
-- 202608270001_initial_schema.sql
-- ============================================================
create extension if not exists pgcrypto;

create type public.app_role as enum ('super_admin','admin','associate','candidate');
create type public.approval_status as enum ('pending_approval','approved','rejected');
create type public.job_status as enum ('draft','pending_review','published','closed','archived');
create type public.work_mode as enum ('remote','hybrid','onsite');
create type public.employment_type as enum ('permanent','contract','internship','freelance','part_time');
create type public.interest_status as enum (
  'interested','profile_reviewed','profile_shared','shortlisted','interview',
  'selected','rejected','on_hold','closed','withdrawn'
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  mobile text,
  approval_status public.approval_status not null default 'pending_approval',
  is_blocked boolean not null default false,
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index profiles_email_lower_uidx on public.profiles(lower(email));

create table public.user_roles (
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.app_role not null,
  granted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key(user_id, role)
);

create table public.admin_invitations (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  full_name text not null,
  role public.app_role not null check (role in ('admin','associate')),
  status text not null default 'pending' check (status in ('pending','accepted','revoked')),
  invited_by uuid not null references auth.users(id),
  invited_user_id uuid references auth.users(id),
  created_at timestamptz not null default now(),
  accepted_at timestamptz
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.skills (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.locations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  country text not null default 'India',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  company_name text,
  client_name text,
  category_id uuid references public.categories(id),
  short_summary text not null default '',
  description text not null,
  duration_text text,
  duration_months integer check (duration_months is null or duration_months between 1 and 120),
  experience_min_years numeric(4,1) check (experience_min_years is null or experience_min_years between 0 and 50),
  experience_max_years numeric(4,1) check (experience_max_years is null or experience_max_years between 0 and 50),
  employment_type public.employment_type not null default 'contract',
  work_mode public.work_mode not null default 'onsite',
  salary_text text,
  keywords text[] not null default '{}',
  locations_text text[] not null default '{}',
  mandatory_skills_text text[] not null default '{}',
  preferred_skills_text text[] not null default '{}',
  status public.job_status not null default 'draft',
  owner_id uuid not null references public.profiles(id),
  assigned_to uuid references public.profiles(id),
  source_text text,
  ai_generated boolean not null default false,
  closes_at timestamptz,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (experience_min_years is null or experience_max_years is null or experience_max_years >= experience_min_years)
);
create index jobs_status_created_idx on public.jobs(status, created_at desc) where deleted_at is null;
create index jobs_category_idx on public.jobs(category_id) where deleted_at is null;
create index jobs_keywords_gin_idx on public.jobs using gin(keywords);

create table public.job_locations (
  job_id uuid not null references public.jobs(id) on delete cascade,
  location_id uuid not null references public.locations(id),
  primary key(job_id, location_id)
);
create table public.job_skills (
  job_id uuid not null references public.jobs(id) on delete cascade,
  skill_id uuid not null references public.skills(id),
  is_mandatory boolean not null default true,
  primary key(job_id, skill_id)
);

create table public.saved_jobs (
  candidate_id uuid not null references public.profiles(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(candidate_id, job_id)
);

create table public.candidate_interests (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  candidate_id uuid not null references public.profiles(id) on delete cascade,
  status public.interest_status not null default 'interested',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  withdrawn_at timestamptz
);
create unique index candidate_interests_job_candidate_uidx on public.candidate_interests(job_id, candidate_id);
create index candidate_interests_job_idx on public.candidate_interests(job_id, created_at desc);

create table public.interest_status_history (
  id uuid primary key default gen_random_uuid(),
  interest_id uuid not null references public.candidate_interests(id) on delete cascade,
  from_status public.interest_status,
  to_status public.interest_status not null,
  changed_by uuid not null references auth.users(id),
  note text,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  actor_role public.app_role,
  action text not null,
  entity_type text not null,
  entity_id text,
  before_data jsonb,
  after_data jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs(created_at desc);

create table public.ai_parse_runs (
  id uuid primary key default gen_random_uuid(),
  requested_by uuid not null references auth.users(id),
  raw_text_hash text not null,
  provider text not null,
  model text,
  success boolean not null,
  fallback_used boolean not null default false,
  extracted_json jsonb,
  error_summary text,
  created_at timestamptz not null default now()
);

create table public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger jobs_set_updated_at before update on public.jobs for each row execute function public.set_updated_at();
create trigger interests_set_updated_at before update on public.candidate_interests for each row execute function public.set_updated_at();

-- ============================================================
-- 202608270002_rls.sql
-- ============================================================
create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer set search_path = public
as $$
  select ur.role from public.user_roles ur join public.profiles p on p.id=ur.user_id
  where ur.user_id = auth.uid() and p.approval_status='approved' and not p.is_blocked
  order by case ur.role when 'super_admin' then 1 when 'admin' then 2 when 'associate' then 3 else 4 end limit 1;
$$;

create or replace function public.is_admin_like()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_app_role() in ('super_admin','admin'), false); $$;

create or replace function public.is_approved_user()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.approval_status='approved' and not p.is_blocked);
$$;

create or replace function public.can_manage_job(target public.jobs)
returns boolean language sql stable security definer set search_path = public
as $$
  select public.current_app_role() in ('super_admin','admin')
    or (public.current_app_role()='associate' and (target.owner_id=auth.uid() or target.assigned_to=auth.uid()));
$$;

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.admin_invitations enable row level security;
alter table public.categories enable row level security;
alter table public.skills enable row level security;
alter table public.locations enable row level security;
alter table public.jobs enable row level security;
alter table public.job_locations enable row level security;
alter table public.job_skills enable row level security;
alter table public.saved_jobs enable row level security;
alter table public.candidate_interests enable row level security;
alter table public.interest_status_history enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;
alter table public.ai_parse_runs enable row level security;
alter table public.platform_settings enable row level security;

create policy profiles_self_read on public.profiles for select using (id=auth.uid());
create policy profiles_admin_read on public.profiles for select using (public.is_admin_like());
create policy profiles_self_update on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
create policy profiles_admin_update on public.profiles for update using (public.is_admin_like()) with check (public.is_admin_like());

create policy roles_self_read on public.user_roles for select using (user_id=auth.uid());
create policy roles_admin_read on public.user_roles for select using (public.is_admin_like());

create policy invitations_admin_read on public.admin_invitations for select using (public.current_app_role()='super_admin');

create policy categories_read on public.categories for select using (auth.uid() is not null);
create policy skills_read on public.skills for select using (auth.uid() is not null);
create policy locations_read on public.locations for select using (auth.uid() is not null);
create policy categories_admin_write on public.categories for all using (public.is_admin_like()) with check (public.is_admin_like());
create policy skills_admin_write on public.skills for all using (public.is_admin_like()) with check (public.is_admin_like());
create policy locations_admin_write on public.locations for all using (public.is_admin_like()) with check (public.is_admin_like());

create policy jobs_candidate_read on public.jobs for select using (
  deleted_at is null and status='published' and public.is_approved_user()
);
create policy jobs_backoffice_read on public.jobs for select using (
  public.current_app_role() in ('super_admin','admin') or (public.current_app_role()='associate' and (owner_id=auth.uid() or assigned_to=auth.uid()))
);
create policy jobs_create on public.jobs for insert with check (
  public.current_app_role() in ('super_admin','admin','associate') and owner_id=auth.uid()
  and status='draft' and published_at is null and deleted_at is null
);
create policy jobs_update on public.jobs for update using (public.can_manage_job(jobs)) with check (public.can_manage_job(jobs));

create policy job_locations_read on public.job_locations for select using (exists(select 1 from public.jobs j where j.id=job_id));
create policy job_skills_read on public.job_skills for select using (exists(select 1 from public.jobs j where j.id=job_id));
create policy job_locations_manage on public.job_locations for all using (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j))) with check (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j)));
create policy job_skills_manage on public.job_skills for all using (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j))) with check (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j)));

create policy saved_jobs_own_read on public.saved_jobs for select using (candidate_id=auth.uid());
create policy saved_jobs_own_insert on public.saved_jobs for insert with check (candidate_id=auth.uid() and public.current_app_role()='candidate' and public.is_approved_user());
create policy saved_jobs_own_delete on public.saved_jobs for delete using (candidate_id=auth.uid());

create policy interests_own_read on public.candidate_interests for select using (candidate_id=auth.uid());
create policy interests_backoffice_read on public.candidate_interests for select using (
  public.is_admin_like() or exists(select 1 from public.jobs j where j.id=job_id and public.current_app_role()='associate' and (j.owner_id=auth.uid() or j.assigned_to=auth.uid()))
);
create policy history_candidate_read on public.interest_status_history for select using (exists(select 1 from public.candidate_interests ci where ci.id=interest_id and ci.candidate_id=auth.uid()));
create policy history_backoffice_read on public.interest_status_history for select using (public.is_admin_like() or exists(select 1 from public.candidate_interests ci join public.jobs j on j.id=ci.job_id where ci.id=interest_id and public.current_app_role()='associate' and (j.owner_id=auth.uid() or j.assigned_to=auth.uid())));

create policy notifications_own_read on public.notifications for select using (user_id=auth.uid());
create policy notifications_own_update on public.notifications for update using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy audit_admin_read on public.audit_logs for select using (public.current_app_role()='super_admin' or (public.current_app_role()='admin' and action not in ('role.changed','admin.invited','user.access_changed')));
create policy ai_runs_owner_read on public.ai_parse_runs for select using (requested_by=auth.uid() or public.is_admin_like());
create policy settings_read on public.platform_settings for select using (auth.uid() is not null);
create policy settings_super_write on public.platform_settings for all using (public.current_app_role()='super_admin') with check (public.current_app_role()='super_admin');

create or replace function public.create_interest_secure(p_job_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid; v_job public.jobs; v_new boolean;
begin
  if public.current_app_role() <> 'candidate' or not public.is_approved_user() then raise exception 'candidate access required'; end if;
  select * into v_job from public.jobs where id=p_job_id and deleted_at is null;
  if v_job.id is null or v_job.status <> 'published' or (v_job.closes_at is not null and v_job.closes_at < now()) then raise exception 'job is not accepting interests'; end if;
  select not exists(select 1 from public.candidate_interests where job_id=p_job_id and candidate_id=auth.uid()) into v_new;
  insert into public.candidate_interests(job_id,candidate_id) values(p_job_id,auth.uid())
  on conflict(job_id,candidate_id) do update set updated_at=now()
  returning id into v_id;
  insert into public.interest_status_history(interest_id,from_status,to_status,changed_by)
  select v_id,null,'interested',auth.uid() where v_new;
  insert into public.notifications(user_id,type,title,body,link)
  select v_job.owner_id,'job.new_interest','New candidate interest','A candidate is interested in '||v_job.title,'/admin/applications'
  where v_new;
  return v_id;
end $$;
grant execute on function public.create_interest_secure(uuid) to authenticated;

-- Column-level privilege hardening: candidates may edit only profile presentation fields.
revoke update on public.profiles from authenticated;
grant update(full_name, mobile, updated_at) on public.profiles to authenticated;

-- Job lifecycle fields are changed only by SECURITY DEFINER lifecycle functions.
revoke update(status, published_at, deleted_at, owner_id) on public.jobs from authenticated;

-- ============================================================
-- 202608270003_auth_profile_trigger.sql
-- ============================================================
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,email,mobile,approval_status)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),coalesce(new.email,''),nullif(new.raw_user_meta_data->>'mobile',''),'pending_approval')
  on conflict(id) do nothing;
  insert into public.user_roles(user_id,role) values(new.id,'candidate') on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ============================================================
-- 202608270004_taxonomy_permissions.sql
-- ============================================================
create or replace function public.set_taxonomy_active(p_table text, p_id uuid, p_active boolean)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin_like() then raise exception 'admin access required'; end if;
  if p_table='categories' then update public.categories set is_active=p_active where id=p_id;
  elsif p_table='skills' then update public.skills set is_active=p_active where id=p_id;
  elsif p_table='locations' then update public.locations set is_active=p_active where id=p_id;
  else raise exception 'invalid taxonomy table'; end if;
end $$;
grant execute on function public.set_taxonomy_active(text,uuid,boolean) to authenticated;

-- ============================================================
-- 202608270005_job_lifecycle.sql
-- ============================================================
create or replace function public.transition_job(p_job_id uuid,p_next public.job_status)
returns public.jobs language plpgsql security definer set search_path=public as $$
declare j public.jobs; r public.app_role; allow_publish boolean;
begin select * into j from public.jobs where id=p_job_id for update; if j.id is null or j.deleted_at is not null then raise exception 'job unavailable'; end if;r:=public.current_app_role();if not public.can_manage_job(j) then raise exception 'job permission denied';end if;select coalesce((value::text)::boolean,false) into allow_publish from public.platform_settings where key='associate_can_publish';
 if p_next='published' then if r='associate' and not coalesce(allow_publish,false) then raise exception 'associate publish permission disabled';end if;if j.title is null or length(trim(j.title))<2 or j.category_id is null or length(trim(j.description))<20 then raise exception 'job is incomplete for publishing';end if;if j.status='archived' then raise exception 'archived job cannot be reopened';end if;if j.status not in ('draft','pending_review','closed','published') then raise exception 'invalid publish transition';end if;
 elsif p_next='closed' and j.status<>'published' then raise exception 'only published jobs can close';
 elsif p_next='pending_review' and j.status<>'draft' then raise exception 'only drafts can enter review';
 elsif p_next='draft' and j.status not in ('pending_review','published') then raise exception 'only pending review or published jobs can return to draft';
 elsif p_next='archived' and j.status='archived' then raise exception 'job already archived'; end if;
 update public.jobs set status=p_next,published_at=case when p_next='published' then coalesce(published_at,now()) else published_at end where id=p_job_id returning * into j;
 insert into public.audit_logs(actor_user_id,actor_role,action,entity_type,entity_id,after_data) values(auth.uid(),r,'job.'||p_next::text,'job',p_job_id::text,jsonb_build_object('status',p_next));return j;end $$;
grant execute on function public.transition_job(uuid,public.job_status) to authenticated;
create or replace function public.soft_delete_job(p_job_id uuid) returns void language plpgsql security definer set search_path=public as $$declare j public.jobs;begin select * into j from public.jobs where id=p_job_id;if not public.can_manage_job(j) then raise exception 'job permission denied';end if;update public.jobs set deleted_at=now() where id=p_job_id;insert into public.audit_logs(actor_user_id,actor_role,action,entity_type,entity_id)values(auth.uid(),public.current_app_role(),'job.deleted','job',p_job_id::text);end$$;grant execute on function public.soft_delete_job(uuid) to authenticated;

-- ============================================================
-- 202608270006_interest_rpc.sql
-- ============================================================
create or replace function public.mark_interest(p_job_id uuid) returns uuid language sql security definer set search_path=public as $$select public.create_interest_secure(p_job_id);$$;grant execute on function public.mark_interest(uuid) to authenticated;
create or replace function public.withdraw_interest(p_job_id uuid) returns uuid language plpgsql security definer set search_path=public as $$declare i public.candidate_interests; enabled boolean;begin select coalesce((value::text)::boolean,true) into enabled from public.platform_settings where key='candidate_withdrawal_enabled';if not coalesce(enabled,true) then raise exception 'withdrawal disabled';end if;select * into i from public.candidate_interests where job_id=p_job_id and candidate_id=auth.uid() for update;if i.id is null then raise exception 'application not found';end if;if i.status in ('selected','rejected','closed','withdrawn') then raise exception 'application cannot be withdrawn';end if;update public.candidate_interests set status='withdrawn',withdrawn_at=now() where id=i.id;insert into public.interest_status_history(interest_id,from_status,to_status,changed_by)values(i.id,i.status,'withdrawn',auth.uid());return i.id;end$$;grant execute on function public.withdraw_interest(uuid) to authenticated;

-- ============================================================
-- 202608270007_application_status.sql
-- ============================================================
create or replace function public.update_application_status(p_interest_id uuid,p_next public.interest_status,p_note text default null) returns public.candidate_interests language plpgsql security definer set search_path=public as $$declare i public.candidate_interests;j public.jobs;r public.app_role;allowed public.interest_status[];old_status public.interest_status;begin select * into i from public.candidate_interests where id=p_interest_id for update;if i.id is null then raise exception 'application not found';end if;select * into j from public.jobs where id=i.job_id;r:=public.current_app_role();if not (r in ('super_admin','admin') or (r='associate' and (j.owner_id=auth.uid() or j.assigned_to=auth.uid()))) then raise exception 'application permission denied';end if;allowed:=case i.status when 'interested' then array['profile_reviewed','profile_shared','shortlisted','rejected','on_hold','closed']::public.interest_status[] when 'profile_reviewed' then array['profile_shared','shortlisted','rejected','on_hold','closed']::public.interest_status[] when 'profile_shared' then array['shortlisted','interview','rejected','on_hold','closed']::public.interest_status[] when 'shortlisted' then array['interview','selected','rejected','on_hold','closed']::public.interest_status[] when 'interview' then array['selected','rejected','on_hold','closed']::public.interest_status[] when 'selected' then array['closed']::public.interest_status[] when 'rejected' then array['closed']::public.interest_status[] when 'on_hold' then array['profile_reviewed','profile_shared','shortlisted','interview','rejected','closed']::public.interest_status[] else array[]::public.interest_status[] end;if not (p_next=any(allowed)) then raise exception 'invalid status transition';end if;old_status:=i.status;update public.candidate_interests set status=p_next where id=i.id returning * into i;insert into public.interest_status_history(interest_id,from_status,to_status,changed_by,note)values(i.id,old_status,p_next,auth.uid(),p_note);insert into public.notifications(user_id,type,title,body,link)values(i.candidate_id,'application.status','Application updated','Your application status is now '||replace(p_next::text,'_',' '),'/applications');insert into public.audit_logs(actor_user_id,actor_role,action,entity_type,entity_id,after_data)values(auth.uid(),r,'application.status_changed','application',i.id::text,jsonb_build_object('status',p_next));return i;end$$;grant execute on function public.update_application_status(uuid,public.interest_status,text) to authenticated;

-- ============================================================
-- 202608270008_dashboard_views.sql
-- ============================================================
create or replace function public.admin_dashboard_metrics()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  out jsonb;
begin
  if not public.is_admin_like() then
    raise exception 'admin access required';
  end if;

  select jsonb_build_object(
    'totalUsers', (select count(*) from profiles),
    'approvedCandidates', (
      select count(*)
      from profiles p
      join user_roles r on r.user_id = p.id and r.role = 'candidate'
      where p.approval_status = 'approved' and not p.is_blocked
    ),
    'pendingApprovals', (
      select count(*)
      from profiles p
      join user_roles r on r.user_id = p.id and r.role = 'candidate'
      where p.approval_status = 'pending_approval'
    ),
    'activeJobs', (select count(*) from jobs where status = 'published' and deleted_at is null),
    'draftJobs', (select count(*) from jobs where status in ('draft','pending_review') and deleted_at is null),
    'closedJobs', (select count(*) from jobs where status = 'closed' and deleted_at is null),
    'totalInterests', (select count(*) from candidate_interests),
    'interestsToday', (
      select count(*) from candidate_interests
      where created_at >= date_trunc('day', now())
    ),
    'statusDistribution', (
      select coalesce(jsonb_agg(x), '[]'::jsonb)
      from (
        select status, count(*) as count
        from candidate_interests
        group by status
        order by count(*) desc
      ) x
    ),
    'topCategories', (
      select coalesce(jsonb_agg(x), '[]'::jsonb)
      from (
        select c.name, count(*) as count
        from jobs j
        join categories c on c.id = j.category_id
        where j.deleted_at is null
        group by c.name
        order by count(*) desc
        limit 5
      ) x
    ),
    'topSkills', (
      select coalesce(
        jsonb_agg(jsonb_build_object('name', skill, 'count', n)),
        '[]'::jsonb
      )
      from (
        select s.skill, count(*) as n
        from jobs j
        cross join unnest(j.mandatory_skills_text) as s(skill)
        where j.deleted_at is null
        group by s.skill
        order by count(*) desc
        limit 5
      ) s
    ),
    'popularJobs', (
      select coalesce(jsonb_agg(x), '[]'::jsonb)
      from (
        select j.id, j.title, count(ci.id) as count
        from jobs j
        left join candidate_interests ci on ci.job_id = j.id
        where j.deleted_at is null
        group by j.id, j.title
        order by count(ci.id) desc
        limit 5
      ) x
    )
  ) into out;

  return out;
end;
$$;

grant execute on function public.admin_dashboard_metrics() to authenticated;

-- ============================================================
-- seed.sql
-- ============================================================
insert into public.categories(name, slug) values
('Data Engineering','data-engineering'),('Data Analytics','data-analytics'),('Data Science','data-science'),
('AI / ML','ai-ml'),('Frontend Development','frontend-development'),('Backend Development','backend-development'),
('Full Stack Development','full-stack-development'),('DevOps','devops'),('Cloud Engineering','cloud-engineering'),
('Cybersecurity','cybersecurity'),('QA / Testing','qa-testing'),('Business Analysis','business-analysis'),
('Product','product'),('Mobile Development','mobile-development'),('Database / DBA','database-dba'),
('ERP / CRM','erp-crm'),('Other','other') on conflict(slug) do nothing;

insert into public.skills(name, slug) values
('Snowflake','snowflake'),('Python','python'),('SQL','sql'),('dbt','dbt'),('ETL/ELT','etl-elt'),
('React','react'),('Node.js','node-js'),('TypeScript','typescript'),('Java','java'),('AWS','aws'),
('Azure','azure'),('GCP','gcp'),('Databricks','databricks'),('Spark','spark'),('Power BI','power-bi'),
('Tableau','tableau'),('DevOps','devops'),('Kubernetes','kubernetes'),('Docker','docker'),('Terraform','terraform')
on conflict(slug) do nothing;

insert into public.locations(name, slug) values
('Remote','remote'),('Delhi','delhi'),('Gurugram','gurugram'),('Noida','noida'),('Pune','pune'),
('Bengaluru','bengaluru'),('Hyderabad','hyderabad'),('Mumbai','mumbai'),('Chennai','chennai'),
('Kolkata','kolkata'),('Ahmedabad','ahmedabad') on conflict(slug) do nothing;

insert into public.platform_settings(key, value) values
('associate_can_publish','false'::jsonb),
('candidate_withdrawal_enabled','true'::jsonb),
('registration_open','true'::jsonb),
('portal_display_name','"TalentBridge"'::jsonb),
('default_page_size','20'::jsonb)
on conflict(key) do nothing;
