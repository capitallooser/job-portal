-- TalentBridge recovery after the original bootstrap failed at dashboard metrics.
-- Run this ONLY if: select to_regclass('public.profiles'); returns public.profiles.
-- It installs the corrected dashboard function and seed data that were after the failed statement.

-- ============================================================
-- 202608270008_dashboard_views.sql
-- ============================================================
create or replace function public.admin_dashboard_metrics() returns jsonb language plpgsql stable security definer set search_path=public as $$declare out jsonb;begin if not public.is_admin_like() then raise exception 'admin access required';end if;select jsonb_build_object('totalUsers',(select count(*) from profiles),'approvedCandidates',(select count(*) from profiles p join user_roles r on r.user_id=p.id and r.role='candidate' where p.approval_status='approved' and not p.is_blocked),'pendingApprovals',(select count(*) from profiles p join user_roles r on r.user_id=p.id and r.role='candidate' where p.approval_status='pending_approval'),'activeJobs',(select count(*) from jobs where status='published' and deleted_at is null),'draftJobs',(select count(*) from jobs where status in('draft','pending_review') and deleted_at is null),'closedJobs',(select count(*) from jobs where status='closed' and deleted_at is null),'totalInterests',(select count(*) from candidate_interests),'interestsToday',(select count(*) from candidate_interests where created_at>=date_trunc('day',now())),'statusDistribution',(select coalesce(jsonb_agg(x),'[]') from (select status,count(*) count from candidate_interests group by status order by count(*) desc)x),'topCategories',(select coalesce(jsonb_agg(x),'[]') from (select c.name,count(*) count from jobs j join categories c on c.id=j.category_id where j.deleted_at is null group by c.name order by count(*) desc limit 5)x),'topSkills',(select coalesce(jsonb_agg(jsonb_build_object('name',skill,'count',n)),'[]') from (select skill,count(*) n from jobs j cross join unnest(j.mandatory_skills_text) as s(skill) where j.deleted_at is null group by skill order by count(*) desc limit 5)s),'popularJobs',(select coalesce(jsonb_agg(x),'[]') from (select j.id,j.title,count(ci.id) count from jobs j left join candidate_interests ci on ci.job_id=j.id where j.deleted_at is null group by j.id,j.title order by count(ci.id) desc limit 5)x)) into out;return out;end$$;grant execute on function public.admin_dashboard_metrics() to authenticated;

-- ============================================================
-- seed.sql
-- ============================================================
insert into public.categories(name, slug) values
('Data Engineering','data-engineering'),('Data Analytics','data-analytics'),('Data Science','data-science'),
('AI / ML','ai-ml'),('Frontend Development','frontend-development'),('Backend Development','backend-development'),
('Full Stack Development','full-stack-development'),('DevOps','devops'),('Cloud Engineering','cloud-engineering'),
('Cybersecurity','cybersecurity'),('QA / Testing','qa-testing'),('Business Analysis','business-analysis'),
('Product','product'),('Mobile Development','mobile-development'),('Database / DBA','database-dba'),
('ERP / CRM','erp-crm'),('Other','other') on conflict(slug) do nothing;

insert into public.skills(name, slug) values
('Snowflake','snowflake'),('Python','python'),('SQL','sql'),('dbt','dbt'),('ETL/ELT','etl-elt'),
('React','react'),('Node.js','node-js'),('TypeScript','typescript'),('Java','java'),('AWS','aws'),
('Azure','azure'),('GCP','gcp'),('Databricks','databricks'),('Spark','spark'),('Power BI','power-bi'),
('Tableau','tableau'),('DevOps','devops'),('Kubernetes','kubernetes'),('Docker','docker'),('Terraform','terraform')
on conflict(slug) do nothing;

insert into public.locations(name, slug) values
('Remote','remote'),('Delhi','delhi'),('Gurugram','gurugram'),('Noida','noida'),('Pune','pune'),
('Bengaluru','bengaluru'),('Hyderabad','hyderabad'),('Mumbai','mumbai'),('Chennai','chennai'),
('Kolkata','kolkata'),('Ahmedabad','ahmedabad') on conflict(slug) do nothing;

insert into public.platform_settings(key, value) values
('associate_can_publish','false'::jsonb),
('candidate_withdrawal_enabled','true'::jsonb),
('registration_open','true'::jsonb),
('portal_display_name','"TalentBridge"'::jsonb),
('default_page_size','20'::jsonb)
on conflict(key) do nothing;
