insert into public.categories(name, slug) values
('Data Engineering','data-engineering'),('Data Analytics','data-analytics'),('Data Science','data-science'),
('AI / ML','ai-ml'),('Frontend Development','frontend-development'),('Backend Development','backend-development'),
('Full Stack Development','full-stack-development'),('DevOps','devops'),('Cloud Engineering','cloud-engineering'),
('Cybersecurity','cybersecurity'),('QA / Testing','qa-testing'),('Business Analysis','business-analysis'),
('Product','product'),('Mobile Development','mobile-development'),('Database / DBA','database-dba'),
('ERP / CRM','erp-crm'),('Other','other') on conflict(slug) do nothing;

insert into public.skills(name, slug) values
('Snowflake','snowflake'),('Python','python'),('SQL','sql'),('dbt','dbt'),('ETL/ELT','etl-elt'),
('React','react'),('Node.js','node-js'),('TypeScript','typescript'),('Java','java'),('AWS','aws'),
('Azure','azure'),('GCP','gcp'),('Databricks','databricks'),('Spark','spark'),('Power BI','power-bi'),
('Tableau','tableau'),('DevOps','devops'),('Kubernetes','kubernetes'),('Docker','docker'),('Terraform','terraform')
on conflict(slug) do nothing;

insert into public.locations(name, slug) values
('Remote','remote'),('Delhi','delhi'),('Gurugram','gurugram'),('Noida','noida'),('Pune','pune'),
('Bengaluru','bengaluru'),('Hyderabad','hyderabad'),('Mumbai','mumbai'),('Chennai','chennai'),
('Kolkata','kolkata'),('Ahmedabad','ahmedabad') on conflict(slug) do nothing;

insert into public.platform_settings(key, value) values
('associate_can_publish','false'::jsonb),
('candidate_withdrawal_enabled','true'::jsonb),
('registration_open','true'::jsonb),
('portal_display_name','"TalentBridge"'::jsonb),
('default_page_size','20'::jsonb)
on conflict(key) do nothing;
