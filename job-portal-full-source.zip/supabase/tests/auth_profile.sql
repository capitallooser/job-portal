begin;
select plan(2);
select has_function('public','handle_new_user',array[]::text[],'auth user profile trigger function exists');
select trigger_is('auth','users','on_auth_user_created','public','handle_new_user','new auth users create portal profiles');
select * from finish();
rollback;
