begin;select plan(1);select has_function('public','update_application_status',array['uuid','interest_status','text'],'status transition rpc exists');select * from finish();rollback;
