import { assertEquals, assertThrows } from 'https://deno.land/std@0.224.0/assert/mod.ts'
import { validateInviteBody } from '../_shared/validation.ts'
Deno.test('invite body accepts admin email invitation',()=>{assertEquals(validateInviteBody({email:' Admin@Example.com ',fullName:'Admin User',role:'admin'}),{email:'admin@example.com',fullName:'Admin User',role:'admin'})})
Deno.test('invite body rejects candidate role',()=>{assertThrows(()=>validateInviteBody({email:'x@example.com',fullName:'User',role:'candidate'}))})
