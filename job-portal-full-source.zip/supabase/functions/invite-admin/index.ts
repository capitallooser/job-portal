import { corsHeaders } from '../_shared/cors.ts'
import { HttpError, requireRole, responseError, serviceClient } from '../_shared/auth.ts'
import { validateInviteBody } from '../_shared/validation.ts'

Deno.serve(async (req)=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:corsHeaders})
  try{
    const actor=await requireRole(req,['super_admin'])
    let parsed; try { parsed=validateInviteBody(await req.json()) } catch(e) { throw new HttpError(400,e instanceof Error?e.message:'Invalid invitation') }
    const { email, fullName, role } = parsed
    const admin=serviceClient()
    const {data,error}=await admin.auth.admin.inviteUserByEmail(email,{data:{full_name:fullName}})
    if(error||!data.user) throw new HttpError(400,error?.message??'Invitation failed')
    const userId=data.user.id
    await admin.from('profiles').upsert({id:userId,full_name:fullName,email,approval_status:'approved',is_blocked:false,approved_by:actor.user.id,approved_at:new Date().toISOString()})
    await admin.from('user_roles').delete().eq('user_id',userId)
    await admin.from('user_roles').insert({user_id:userId,role,granted_by:actor.user.id})
    const {data:inv,error:invError}=await admin.from('admin_invitations').insert({email,full_name:fullName,role,invited_by:actor.user.id,invited_user_id:userId}).select('id').single()
    if(invError) throw invError
    await admin.from('audit_logs').insert({actor_user_id:actor.user.id,actor_role:actor.role,action:'admin.invited',entity_type:'user',entity_id:userId,after_data:{email,role}})
    return new Response(JSON.stringify({invitationId:inv.id,userId,role}),{headers:{...corsHeaders,'content-type':'application/json'}})
  }catch(e){const r=responseError(e);Object.entries(corsHeaders).forEach(([k,v])=>r.headers.set(k,v));return r}
})
