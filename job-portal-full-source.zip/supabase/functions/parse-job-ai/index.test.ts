import { assertEquals, assertThrows } from 'https://deno.land/std@0.224.0/assert/mod.ts'
import { validateRawJobBody } from '../_shared/validation.ts'
Deno.test('raw job requires meaningful source text',()=>assertThrows(()=>validateRawJobBody({rawText:'short'})))
Deno.test('raw job preserves source',()=>{const t='Data Engineer with Snowflake, Python and dbt for six months.';assertEquals(validateRawJobBody({rawText:t}),t)})
