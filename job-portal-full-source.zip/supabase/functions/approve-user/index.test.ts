import { assertEquals, assertThrows } from 'https://deno.land/std@0.224.0/assert/mod.ts'
import { validateApprovalBody } from '../_shared/validation.ts'
Deno.test('approval accepts block action',()=>assertEquals(validateApprovalBody({userId:'abc',decision:'blocked'}),{userId:'abc',decision:'blocked'}))
Deno.test('approval rejects unknown decision',()=>assertThrows(()=>validateApprovalBody({userId:'abc',decision:'promote'})))
