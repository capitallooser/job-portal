import { createClient } from 'npm:@supabase/supabase-js@2'

export type AppRole = 'super_admin'|'admin'|'associate'|'candidate'
export class HttpError extends Error { constructor(public status:number, message:string){super(message)} }

function env(name: string){ const value=Deno.env.get(name); if(!value) throw new Error(`Missing server environment: ${name}`); return value }
export function serviceClient(){
  return createClient(env('SUPABASE_URL'), env('SUPABASE_' + 'SERVICE_ROLE_KEY'), { auth:{persistSession:false,autoRefreshToken:false} })
}
export async function requireRole(req: Request, allowed: AppRole[]) {
  const token=req.headers.get('Authorization')?.replace(/^Bearer\s+/i,'')
  if(!token) throw new HttpError(401,'Missing bearer token')
  const userClient=createClient(env('SUPABASE_URL'),env('SUPABASE_ANON_KEY'),{global:{headers:{Authorization:`Bearer ${token}`}},auth:{persistSession:false}})
  const {data:{user},error}=await userClient.auth.getUser(token)
  if(error||!user) throw new HttpError(401,'Invalid session')
  const [{data:roles,error:roleError},{data:profile,error:profileError}]=await Promise.all([userClient.from('user_roles').select('role').eq('user_id',user.id),userClient.from('profiles').select('approval_status,is_blocked').eq('id',user.id).single()])
  if(roleError||profileError) throw new HttpError(403,'Unable to resolve role')
  if(profile?.approval_status!=='approved'||profile?.is_blocked) throw new HttpError(403,'Account is not active')
  const role=(roles??[]).map((r)=>r.role as AppRole).find((r)=>allowed.includes(r))
  if(!role) throw new HttpError(403,'Insufficient permissions')
  return { user, role, userClient }
}
export function responseError(error: unknown){
  const status=error instanceof HttpError?error.status:500
  const message=error instanceof Error?error.message:'Unexpected error'
  return new Response(JSON.stringify({error:message}),{status,headers:{'content-type':'application/json'}})
}
