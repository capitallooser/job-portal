export function validateInviteBody(body: unknown) {
  const b = body as Record<string, unknown>
  const email = String(b?.email ?? '').trim().toLowerCase()
  const fullName = String(b?.fullName ?? '').trim()
  const role = b?.role
  if (!email.includes('@') || fullName.length < 2 || !['admin', 'associate'].includes(String(role))) {
    throw new Error('Valid email, name and role are required')
  }
  return { email, fullName, role: role as 'admin' | 'associate' }
}

export function validateApprovalBody(body: unknown) {
  const b = body as Record<string, unknown>
  const userId = String(b?.userId ?? '')
  const decision = String(b?.decision ?? '')
  if (!userId || !['approved', 'rejected', 'blocked'].includes(decision)) throw new Error('Invalid decision')
  return { userId, decision: decision as 'approved' | 'rejected' | 'blocked' }
}

export function validateRawJobBody(body: unknown) {
  const rawText = String((body as Record<string, unknown>)?.rawText ?? '')
  if (rawText.trim().length < 20) throw new Error('Paste a job description of at least 20 characters')
  return rawText
}
