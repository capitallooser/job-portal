create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer set search_path = public
as $$
  select ur.role from public.user_roles ur join public.profiles p on p.id=ur.user_id
  where ur.user_id = auth.uid() and p.approval_status='approved' and not p.is_blocked
  order by case ur.role when 'super_admin' then 1 when 'admin' then 2 when 'associate' then 3 else 4 end limit 1;
$$;

create or replace function public.is_admin_like()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_app_role() in ('super_admin','admin'), false); $$;

create or replace function public.is_approved_user()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.approval_status='approved' and not p.is_blocked);
$$;

create or replace function public.can_manage_job(target public.jobs)
returns boolean language sql stable security definer set search_path = public
as $$
  select public.current_app_role() in ('super_admin','admin')
    or (public.current_app_role()='associate' and (target.owner_id=auth.uid() or target.assigned_to=auth.uid()));
$$;

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.admin_invitations enable row level security;
alter table public.categories enable row level security;
alter table public.skills enable row level security;
alter table public.locations enable row level security;
alter table public.jobs enable row level security;
alter table public.job_locations enable row level security;
alter table public.job_skills enable row level security;
alter table public.saved_jobs enable row level security;
alter table public.candidate_interests enable row level security;
alter table public.interest_status_history enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;
alter table public.ai_parse_runs enable row level security;
alter table public.platform_settings enable row level security;

create policy profiles_self_read on public.profiles for select using (id=auth.uid());
create policy profiles_admin_read on public.profiles for select using (public.is_admin_like());
create policy profiles_self_update on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
create policy profiles_admin_update on public.profiles for update using (public.is_admin_like()) with check (public.is_admin_like());

create policy roles_self_read on public.user_roles for select using (user_id=auth.uid());
create policy roles_admin_read on public.user_roles for select using (public.is_admin_like());

create policy invitations_admin_read on public.admin_invitations for select using (public.current_app_role()='super_admin');

create policy categories_read on public.categories for select using (auth.uid() is not null);
create policy skills_read on public.skills for select using (auth.uid() is not null);
create policy locations_read on public.locations for select using (auth.uid() is not null);
create policy categories_admin_write on public.categories for all using (public.is_admin_like()) with check (public.is_admin_like());
create policy skills_admin_write on public.skills for all using (public.is_admin_like()) with check (public.is_admin_like());
create policy locations_admin_write on public.locations for all using (public.is_admin_like()) with check (public.is_admin_like());

create policy jobs_candidate_read on public.jobs for select using (
  deleted_at is null and status='published' and public.is_approved_user()
);
create policy jobs_backoffice_read on public.jobs for select using (
  public.current_app_role() in ('super_admin','admin') or (public.current_app_role()='associate' and (owner_id=auth.uid() or assigned_to=auth.uid()))
);
create policy jobs_create on public.jobs for insert with check (
  public.current_app_role() in ('super_admin','admin','associate') and owner_id=auth.uid()
  and status='draft' and published_at is null and deleted_at is null
);
create policy jobs_update on public.jobs for update using (public.can_manage_job(jobs)) with check (public.can_manage_job(jobs));

create policy job_locations_read on public.job_locations for select using (exists(select 1 from public.jobs j where j.id=job_id));
create policy job_skills_read on public.job_skills for select using (exists(select 1 from public.jobs j where j.id=job_id));
create policy job_locations_manage on public.job_locations for all using (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j))) with check (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j)));
create policy job_skills_manage on public.job_skills for all using (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j))) with check (exists(select 1 from public.jobs j where j.id=job_id and public.can_manage_job(j)));

create policy saved_jobs_own_read on public.saved_jobs for select using (candidate_id=auth.uid());
create policy saved_jobs_own_insert on public.saved_jobs for insert with check (candidate_id=auth.uid() and public.current_app_role()='candidate' and public.is_approved_user());
create policy saved_jobs_own_delete on public.saved_jobs for delete using (candidate_id=auth.uid());

create policy interests_own_read on public.candidate_interests for select using (candidate_id=auth.uid());
create policy interests_backoffice_read on public.candidate_interests for select using (
  public.is_admin_like() or exists(select 1 from public.jobs j where j.id=job_id and public.current_app_role()='associate' and (j.owner_id=auth.uid() or j.assigned_to=auth.uid()))
);
create policy history_candidate_read on public.interest_status_history for select using (exists(select 1 from public.candidate_interests ci where ci.id=interest_id and ci.candidate_id=auth.uid()));
create policy history_backoffice_read on public.interest_status_history for select using (public.is_admin_like() or exists(select 1 from public.candidate_interests ci join public.jobs j on j.id=ci.job_id where ci.id=interest_id and public.current_app_role()='associate' and (j.owner_id=auth.uid() or j.assigned_to=auth.uid())));

create policy notifications_own_read on public.notifications for select using (user_id=auth.uid());
create policy notifications_own_update on public.notifications for update using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy audit_admin_read on public.audit_logs for select using (public.current_app_role()='super_admin' or (public.current_app_role()='admin' and action not in ('role.changed','admin.invited','user.access_changed')));
create policy ai_runs_owner_read on public.ai_parse_runs for select using (requested_by=auth.uid() or public.is_admin_like());
create policy settings_read on public.platform_settings for select using (auth.uid() is not null);
create policy settings_super_write on public.platform_settings for all using (public.current_app_role()='super_admin') with check (public.current_app_role()='super_admin');

create or replace function public.create_interest_secure(p_job_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid; v_job public.jobs; v_new boolean;
begin
  if public.current_app_role() <> 'candidate' or not public.is_approved_user() then raise exception 'candidate access required'; end if;
  select * into v_job from public.jobs where id=p_job_id and deleted_at is null;
  if v_job.id is null or v_job.status <> 'published' or (v_job.closes_at is not null and v_job.closes_at < now()) then raise exception 'job is not accepting interests'; end if;
  select not exists(select 1 from public.candidate_interests where job_id=p_job_id and candidate_id=auth.uid()) into v_new;
  insert into public.candidate_interests(job_id,candidate_id) values(p_job_id,auth.uid())
  on conflict(job_id,candidate_id) do update set updated_at=now()
  returning id into v_id;
  insert into public.interest_status_history(interest_id,from_status,to_status,changed_by)
  select v_id,null,'interested',auth.uid() where v_new;
  insert into public.notifications(user_id,type,title,body,link)
  select v_job.owner_id,'job.new_interest','New candidate interest','A candidate is interested in '||v_job.title,'/admin/applications'
  where v_new;
  return v_id;
end $$;
grant execute on function public.create_interest_secure(uuid) to authenticated;

-- Column-level privilege hardening: candidates may edit only profile presentation fields.
revoke update on public.profiles from authenticated;
grant update(full_name, mobile, updated_at) on public.profiles to authenticated;

-- Job lifecycle fields are changed only by SECURITY DEFINER lifecycle functions.
revoke update(status, published_at, deleted_at, owner_id) on public.jobs from authenticated;
