create extension if not exists pgcrypto;

create type public.app_role as enum ('super_admin','admin','associate','candidate');
create type public.approval_status as enum ('pending_approval','approved','rejected');
create type public.job_status as enum ('draft','pending_review','published','closed','archived');
create type public.work_mode as enum ('remote','hybrid','onsite');
create type public.employment_type as enum ('permanent','contract','internship','freelance','part_time');
create type public.interest_status as enum (
  'interested','profile_reviewed','profile_shared','shortlisted','interview',
  'selected','rejected','on_hold','closed','withdrawn'
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  mobile text,
  approval_status public.approval_status not null default 'pending_approval',
  is_blocked boolean not null default false,
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index profiles_email_lower_uidx on public.profiles(lower(email));

create table public.user_roles (
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.app_role not null,
  granted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key(user_id, role)
);

create table public.admin_invitations (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  full_name text not null,
  role public.app_role not null check (role in ('admin','associate')),
  status text not null default 'pending' check (status in ('pending','accepted','revoked')),
  invited_by uuid not null references auth.users(id),
  invited_user_id uuid references auth.users(id),
  created_at timestamptz not null default now(),
  accepted_at timestamptz
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.skills (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.locations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  country text not null default 'India',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  company_name text,
  client_name text,
  category_id uuid references public.categories(id),
  short_summary text not null default '',
  description text not null,
  duration_text text,
  duration_months integer check (duration_months is null or duration_months between 1 and 120),
  experience_min_years numeric(4,1) check (experience_min_years is null or experience_min_years between 0 and 50),
  experience_max_years numeric(4,1) check (experience_max_years is null or experience_max_years between 0 and 50),
  employment_type public.employment_type not null default 'contract',
  work_mode public.work_mode not null default 'onsite',
  salary_text text,
  keywords text[] not null default '{}',
  locations_text text[] not null default '{}',
  mandatory_skills_text text[] not null default '{}',
  preferred_skills_text text[] not null default '{}',
  status public.job_status not null default 'draft',
  owner_id uuid not null references public.profiles(id),
  assigned_to uuid references public.profiles(id),
  source_text text,
  ai_generated boolean not null default false,
  closes_at timestamptz,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (experience_min_years is null or experience_max_years is null or experience_max_years >= experience_min_years)
);
create index jobs_status_created_idx on public.jobs(status, created_at desc) where deleted_at is null;
create index jobs_category_idx on public.jobs(category_id) where deleted_at is null;
create index jobs_keywords_gin_idx on public.jobs using gin(keywords);

create table public.job_locations (
  job_id uuid not null references public.jobs(id) on delete cascade,
  location_id uuid not null references public.locations(id),
  primary key(job_id, location_id)
);
create table public.job_skills (
  job_id uuid not null references public.jobs(id) on delete cascade,
  skill_id uuid not null references public.skills(id),
  is_mandatory boolean not null default true,
  primary key(job_id, skill_id)
);

create table public.saved_jobs (
  candidate_id uuid not null references public.profiles(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(candidate_id, job_id)
);

create table public.candidate_interests (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  candidate_id uuid not null references public.profiles(id) on delete cascade,
  status public.interest_status not null default 'interested',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  withdrawn_at timestamptz
);
create unique index candidate_interests_job_candidate_uidx on public.candidate_interests(job_id, candidate_id);
create index candidate_interests_job_idx on public.candidate_interests(job_id, created_at desc);

create table public.interest_status_history (
  id uuid primary key default gen_random_uuid(),
  interest_id uuid not null references public.candidate_interests(id) on delete cascade,
  from_status public.interest_status,
  to_status public.interest_status not null,
  changed_by uuid not null references auth.users(id),
  note text,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  actor_role public.app_role,
  action text not null,
  entity_type text not null,
  entity_id text,
  before_data jsonb,
  after_data jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs(created_at desc);

create table public.ai_parse_runs (
  id uuid primary key default gen_random_uuid(),
  requested_by uuid not null references auth.users(id),
  raw_text_hash text not null,
  provider text not null,
  model text,
  success boolean not null,
  fallback_used boolean not null default false,
  extracted_json jsonb,
  error_summary text,
  created_at timestamptz not null default now()
);

create table public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger jobs_set_updated_at before update on public.jobs for each row execute function public.set_updated_at();
create trigger interests_set_updated_at before update on public.candidate_interests for each row execute function public.set_updated_at();
