create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,email,mobile,approval_status)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),coalesce(new.email,''),nullif(new.raw_user_meta_data->>'mobile',''),'pending_approval')
  on conflict(id) do nothing;
  insert into public.user_roles(user_id,role) values(new.id,'candidate') on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
