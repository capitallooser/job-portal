create or replace function public.set_taxonomy_active(p_table text, p_id uuid, p_active boolean)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_admin_like() then raise exception 'admin access required'; end if;
  if p_table='categories' then update public.categories set is_active=p_active where id=p_id;
  elsif p_table='skills' then update public.skills set is_active=p_active where id=p_id;
  elsif p_table='locations' then update public.locations set is_active=p_active where id=p_id;
  else raise exception 'invalid taxonomy table'; end if;
end $$;
grant execute on function public.set_taxonomy_active(text,uuid,boolean) to authenticated;
