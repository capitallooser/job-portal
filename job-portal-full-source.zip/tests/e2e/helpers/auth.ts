import type { Page } from '@playwright/test'
export const e2eReady = process.env.RUN_E2E === '1'
export async function login(page:Page,email:string,password:string){await page.goto('/#/login');await page.getByLabel('Email').fill(email);await page.getByLabel('Password').fill(password);await page.getByRole('button',{name:'Sign in'}).click()}
export function credentials(prefix:string){const email=process.env[`${prefix}_EMAIL`];const password=process.env[`${prefix}_PASSWORD`];if(!email||!password)throw new Error(`Missing ${prefix}_EMAIL/PASSWORD`);return{email,password}}
