// E2E database seeding is intentionally external to browser code.
// Use a dedicated Supabase test project or local `supabase db reset` and the documented seeded accounts.
export const requiredE2eRoles=['super_admin','admin','associate','candidate'] as const
