# Zero-Cost Deployment Guide

The portal uses GitLab Pages for the React frontend and Supabase Free for authentication, PostgreSQL, RLS, and Edge Functions. The AI provider is optional: without Cloudflare credentials the deterministic parser remains available, so job posting never becomes paid-only.

## 1. Create the Supabase project
1. Create a Supabase Free project.
2. In **Project Settings → API**, copy the project URL and public anon/publishable key.
3. Install the Supabase CLI locally, run `supabase login`, then `supabase link --project-ref <ref>`.
4. Apply schema: `supabase db push`.
5. Run `supabase/seed.sql` in SQL Editor (or `supabase db reset` for local development).

## 2. Configure authentication
In **Authentication → URL Configuration** set the Site URL to the final GitLab Pages URL and add both the Pages URL and localhost redirect URLs. Email confirmation remains enabled.

Supabase's built-in mail service is suitable for initial/testing use but can have delivery/rate restrictions. For a larger private portal, connect any SMTP account/provider that has a free allowance. This does not change application code.

## 3. Bootstrap the first Super Admin
Follow `docs/setup.md`. Create one Auth user and assign the `super_admin` role through SQL Editor. All later Admin/Associate accounts are invited from the portal by email.

## 4. Deploy Edge Functions
```bash
supabase functions deploy invite-admin
supabase functions deploy change-user-role
supabase functions deploy approve-user
supabase functions deploy parse-job-ai
supabase functions deploy publish-job
supabase functions deploy send-notification-email
```
Supabase supplies its own server URL/key environment to Edge Functions. Do not add a privileged key to GitLab frontend variables.

## 5. Optional zero-cost AI provider
If using Cloudflare Workers AI, set server-only secrets in Supabase:
```bash
supabase secrets set CLOUDFLARE_ACCOUNT_ID=<account-id>
supabase secrets set CLOUDFLARE_API_TOKEN=<token>
supabase secrets set CLOUDFLARE_AI_MODEL=@cf/meta/llama-3.1-8b-instruct-fast
```
If these are absent, `parse-job-ai` catches the provider error and returns the deterministic fallback draft.

## 6. Create the GitLab project
Push this repository to GitLab. In **Settings → CI/CD → Variables**, add:
- `VITE_SUPABASE_URL` — public project URL.
- `VITE_SUPABASE_ANON_KEY` — public anon/publishable key.
- `VITE_APP_NAME` — optional display name.

These are browser-safe values. Never add a Supabase privileged/service key as a `VITE_` variable.

The pipeline verifies, builds, and deploys the `dist` artifact as GitLab Pages on the default branch. Vite automatically uses `CI_PROJECT_NAME` as its base path, and the app uses hash routing so deep links work on static hosting.

## 7. Smoke test after deployment
1. Open the Pages URL and request candidate access.
2. Verify the email and confirm the account remains pending.
3. Sign in as Super Admin and approve the candidate.
4. Invite an Admin or Associate by email.
5. Open **AI Import**, paste a raw JD, generate and review a draft.
6. Select/confirm the category, edit any fields, save, and publish.
7. Sign in as candidate and filter/search the job.
8. Save the job and click **Interested** twice; only one application should exist.
9. Update the status as Admin and confirm the candidate timeline/notification changes.

## 8. Optional E2E pipeline
Use a dedicated test project and set `RUN_E2E=1` plus the role credentials described in `tests/e2e/helpers/auth.ts`. The E2E job does not run by default because it requires seeded test accounts and a live/local Supabase environment.
