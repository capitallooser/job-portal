# Acceptance Checklist

| # | Acceptance criterion | Automated evidence | Manual/deployment evidence | Status |
|---|---|---|---|---|
| 1 | Candidate registers, verifies email, remains pending, then gains access after approval | `authSchemas.test.ts`, RLS/auth SQL tests, `candidate.spec.ts` | Signup → email → Admin Approvals smoke flow | Implemented; runtime verification requires Supabase |
| 2 | Super Admin invites Admin/Associate by email and manages access/role | `AdminManagementPage.test.tsx`, Edge authorization tests contract | Super Admin → Admin Management | Implemented |
| 3 | Authorized poster pastes raw JD and receives editable structured draft | `fallbackParser.test.ts`, `AiImportPage.test.tsx`, AI E2E | AI Import smoke flow | Implemented |
| 4 | Draft publishes as searchable/filterable job | job schema/search/lifecycle tests | Publish then search by category/location/skill | Implemented |
| 5 | Candidate saves jobs and marks Interest exactly once | unique DB index + interest RPC tests + candidate E2E | Click Interested twice; one application | Implemented |
| 6 | Admin views candidates and updates status | `applicationStatus.test.ts`, SQL transition tests | Applicants → Review → change status | Implemented |
| 7 | Candidate sees own status history | My Applications test + RLS history policy | Candidate My Applications timeline | Implemented |
| 8 | Role restrictions cannot be bypassed at DB/API layer | RLS policies, column grants, Security Definer checks | Direct API negative tests in local Supabase | Implemented; DB runtime verification required |
| 9 | Frontend builds/deploys through GitLab Pages | `.gitlab-ci.yml`, `vite.config.ts` | Successful GitLab pipeline + Pages URL | Configured |
| 10 | Backend remains within zero-cost architecture | fallback provider path and free-tier architecture | Supabase Free + optional Cloudflare AI | Implemented architecture |
| 11 | Core flows have automated tests | Vitest, pgTAP SQL tests, Playwright journeys | Run complete verification suite | Authored; execution requires dependencies/runtime |
| 12 | New owner can deploy from scratch | README + setup + deployment docs | Follow docs on fresh projects | Complete |
