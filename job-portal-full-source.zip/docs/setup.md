# Local and Supabase Setup

## Prerequisites
Node 22+ and the Supabase CLI (local install is fine). Docker is required only for the local Supabase stack.

## Frontend
1. Copy `.env.example` to `.env.local`.
2. Put the public Supabase project URL and anon/publishable key in the two `VITE_` variables.
3. Run `npm install` then `npm run dev`.

## Database
Run `supabase link --project-ref <project-ref>` and `supabase db push`, then run the seed with `supabase db reset` locally or SQL Editor for a hosted project.

## Bootstrap the first Super Admin
Create the first user through Supabase Authentication (Dashboard → Authentication → Users → Add user). Copy that user's UUID. Then run the following in Supabase SQL Editor with the UUID substituted:

```sql
update public.profiles
set approval_status='approved', is_blocked=false, approved_at=now()
where id='<FIRST_USER_UUID>';

delete from public.user_roles where user_id='<FIRST_USER_UUID>';
insert into public.user_roles(user_id, role) values ('<FIRST_USER_UUID>','super_admin');
```

This is a one-time bootstrap. Never put the service-role key in frontend variables or GitLab Pages.

## Edge Functions
Deploy the privileged functions after linking the project:

```bash
supabase functions deploy invite-admin
supabase functions deploy change-user-role
supabase functions deploy approve-user
supabase functions deploy parse-job-ai
supabase functions deploy publish-job
```
