# AI Job Portal — Full System Design

Date: 2026-08-27
Status: Approved on 2026-08-27; full source implementation authored on feature/full-build; runtime verification pending dependency-enabled environment

## 1. Product Goal

Build a zero-cost, production-style job portal that supports controlled membership, multiple back-office roles, AI-assisted job posting, rich job search/filtering, candidate interest/application tracking, dashboards, notifications, and auditability.

The system must remain deployable without paid infrastructure by default. Paid-only features such as SMS OTP are explicitly excluded from the initial production configuration unless a truly free provider is later substituted.

## 2. User Roles

### Super Admin
- Full system access.
- Invite, activate, deactivate, block, and remove Admins and Associates.
- Assign or revoke roles.
- Approve/reject/block candidates.
- Create, edit, publish, close, reopen, archive, and delete any job.
- View every candidate interest/application.
- Update application statuses.
- View audit logs and platform analytics.
- Configure categories, skills, locations, and platform settings.

### Admin
- Approve/reject/block candidates.
- Invite and manage Associates if granted permission.
- Create, edit, publish, close, reopen, and archive jobs.
- View candidate interests/applications.
- Update application statuses.
- View operational dashboards.
- Cannot remove or demote a Super Admin.

### Associate
- Create jobs.
- Use AI JD Import.
- Edit jobs they own or are assigned to, subject to permissions.
- Publish jobs if granted publish permission; otherwise submit drafts for Admin review.
- View candidate interests for jobs they own or are assigned to.
- Update candidate status if granted permission.

### Candidate / Member
- Self-register.
- Verify email.
- Wait for admin approval.
- Log in only after approval.
- Browse/search/filter active jobs.
- View job details.
- Mark jobs as Interested.
- Withdraw interest where allowed.
- Track application status.
- Maintain basic profile.
- Save jobs.

## 3. Authentication and Access Model

### Candidate onboarding
1. Candidate submits name, email, mobile number, and password.
2. Email verification is required.
3. Account status becomes `pending_approval`.
4. Candidate cannot access protected job content until approved.
5. Admin/Super Admin approves or rejects account.
6. Approved account receives access to the portal.

### Admin/Associate onboarding
1. Super Admin enters name, email, and role.
2. System sends an invitation email.
3. Invitee creates a password through a secure invite link.
4. Role is attached server-side.
5. User can log in immediately after completing the invite flow unless manually disabled.

### Security requirements
- No privileged service key may appear in frontend code.
- Role checks must be enforced server-side/database-side, not only in UI.
- Supabase Row Level Security (RLS) must protect all user-owned and role-restricted records.
- Admin invitation and role-management operations must execute through protected Edge Functions or equivalent server-side functions.

## 4. Job Posting Modes

### AI Import mode
Admin/Associate pastes an entire raw JD, email, WhatsApp-style requirement, recruiter note, or formatted job description into one text area.

The AI parser returns structured data including:
- Job title
- Normalized category
- Company/client name when present
- Project duration
- Experience minimum
- Experience maximum
- Employment type
- Work mode: remote/hybrid/onsite
- Location(s)
- Mandatory skills
- Nice-to-have skills
- Salary/rate when present
- Joining urgency when present
- Notice period preference when present
- Job description
- Search keywords/tags
- Suggested short summary
- Confidence score by extracted field

### Review-before-publish
AI output always creates a draft.

Flow:
`Paste JD -> Parse -> Structured Preview -> Edit -> Save Draft / Publish`

AI must never silently publish directly to production.

### Manual mode
A complete manual form remains available as fallback and for precise editing.

## 5. AI Parsing Strategy

### Primary path
Use a free-tier LLM endpoint suitable for structured extraction. Current preferred architecture: Cloudflare Workers AI or another free-tier provider whose billing can be safely capped at zero.

### Output contract
AI must return strict JSON matching a validated schema.

Example fields:
- `title`
- `category_slug`
- `duration_months`
- `experience_min_years`
- `experience_max_years`
- `employment_type`
- `work_mode`
- `locations[]`
- `mandatory_skills[]`
- `preferred_skills[]`
- `salary_text`
- `description_markdown`
- `keywords[]`
- `field_confidence{}`

### Fallback path
If AI fails or quota is unavailable:
- Preserve the pasted text.
- Run deterministic regex/keyword extraction for obvious fields such as experience, duration, location labels, and skill lists.
- Return an editable draft rather than failing the posting workflow.

### Guardrails
- Distinguish mandatory vs preferred skills.
- Never invent salary, location, experience, or company values not found in source text.
- Preserve ambiguous values as blank/unknown and flag them for review.
- Sanitize generated HTML/Markdown before display.

## 6. Job Taxonomy

Initial categories:
- Data Engineering
- Data Analytics
- Data Science
- AI / ML
- Frontend Development
- Backend Development
- Full Stack Development
- DevOps
- Cloud Engineering
- Cybersecurity
- QA / Testing
- Business Analysis
- Product
- Mobile Development
- Database / DBA
- ERP / CRM
- Other

Work modes:
- Remote
- Hybrid
- Onsite

Employment types:
- Permanent
- Contract
- Internship
- Freelance
- Part-time

Experience ranges are stored numerically and displayed dynamically instead of being hard-coded only as buckets.

## 7. Candidate Experience

### Public pages
- Landing page
- Login
- Sign up
- Forgot/reset password
- Email verification state
- Access pending page
- Privacy / terms placeholders

### Protected candidate pages
- Job feed
- Job details
- Search and filters
- Saved jobs
- My Interests / Applications
- Profile
- Notifications

### Search/filter dimensions
- Keyword
- Job title
- Skill
- Category
- Location
- Remote/hybrid/onsite
- Employment type
- Experience range
- Company/client
- Date posted
- Duration

### Candidate job actions
- Interested
- Withdraw interest
- Save job
- Unsave job
- Copy/share job link

## 8. Application / Interest Workflow

Candidate statuses:
- Interested
- Profile Reviewed
- Profile Shared
- Shortlisted
- Interview
- Selected
- Rejected
- On Hold
- Closed
- Withdrawn

Rules:
- A candidate can have at most one active interest record per job.
- Repeated clicks must be idempotent.
- Status changes are logged in history.
- Candidate can see only their own application history.
- Admin/authorized Associate can see applicants only for jobs within their permission scope.

## 9. Admin Dashboard

### KPIs
- Total users
- Approved candidates
- Pending approvals
- Active jobs
- Draft jobs
- Closed jobs
- Total interests
- Interests today
- Applications by status
- Top categories
- Top skills
- Jobs with most interest

### Admin modules
- User approvals
- Admin management
- Associate management
- Job management
- Application management
- Category/skill/location management
- Notifications
- Audit logs
- Platform settings

## 10. Job Management

Job states:
- Draft
- Pending Review
- Published
- Closed
- Archived

Supported actions:
- Create
- AI import
- Edit
- Duplicate
- Publish
- Unpublish
- Close
- Reopen
- Archive
- Delete/soft-delete

Important mutations are audit logged.

## 11. Notifications

In-app notifications are included in the base system.

Initial notification events:
- Candidate account approved/rejected
- Admin/Associate invitation created
- New candidate interest on a job
- Application status changed
- Job assigned to Associate
- Job approaching closing date

Email notifications are supported where the free provider allows them.

SMS/WhatsApp notifications are excluded from guaranteed zero-cost operation.

## 12. Audit Logging

Audit log captures:
- Actor user ID
- Actor role
- Action
- Entity type
- Entity ID
- Before/after summary where safe
- Timestamp
- Optional metadata

Audit examples:
- user.approved
- role.changed
- admin.invited
- job.published
- job.closed
- application.status_changed

## 13. Database Model

Core tables:
- `profiles`
- `user_roles`
- `role_permissions`
- `admin_invitations`
- `jobs`
- `job_categories`
- `skills`
- `job_skills`
- `job_locations`
- `candidate_interests`
- `interest_status_history`
- `saved_jobs`
- `notifications`
- `audit_logs`
- `ai_parse_runs`
- `platform_settings`

### profiles
- id (UUID, FK auth.users)
- full_name
- email
- mobile
- approval_status
- is_blocked
- created_at
- updated_at
- approved_by
- approved_at

### user_roles
- user_id
- role (`super_admin`, `admin`, `associate`, `candidate`)
- granted_by
- granted_at

### jobs
- id
- slug
- title
- company_name
- client_name
- category_id
- short_summary
- description
- duration_text
- duration_months
- experience_min_years
- experience_max_years
- employment_type
- work_mode
- salary_text
- status
- source_text
- ai_generated
- created_by
- assigned_to
- published_at
- closes_at
- created_at
- updated_at
- deleted_at

### candidate_interests
- id
- job_id
- candidate_id
- status
- created_at
- updated_at
- withdrawn_at

Unique constraint: `(job_id, candidate_id)`.

### ai_parse_runs
- id
- requested_by
- raw_text_hash
- provider
- model
- success
- fallback_used
- extracted_json
- error_summary
- created_at

Do not store secrets or raw provider credentials.

## 14. Row Level Security Design

### Candidate
- Read published/non-deleted jobs.
- Read own profile.
- Update allowed profile fields only.
- Read/write own saved jobs.
- Read/write own candidate interests subject to business rules.
- Read own notifications.

### Associate
- Candidate permissions plus back-office access granted by role.
- Read/edit jobs created by or assigned to them.
- Read candidates interested in authorized jobs.

### Admin
- Read/manage candidates.
- Read/manage all ordinary jobs and applications.
- Cannot alter Super Admin role without explicit privileged policy.

### Super Admin
- Full controlled administrative access.

## 15. Frontend Architecture

Recommended:
- React
- TypeScript
- Vite
- Tailwind CSS
- React Router
- TanStack Query
- Zod
- React Hook Form
- Supabase JavaScript client

Structure:
- `src/app`
- `src/components`
- `src/features/auth`
- `src/features/jobs`
- `src/features/admin`
- `src/features/applications`
- `src/features/notifications`
- `src/features/ai-import`
- `src/lib`
- `src/types`

The app uses feature-based modules and shared typed API helpers.

## 16. Backend / Server Architecture

Supabase provides:
- PostgreSQL
- Auth
- RLS
- Storage
- Realtime where useful
- Edge Functions for privileged operations

Edge Functions:
- `invite-admin`
- `change-user-role`
- `approve-user`
- `parse-job-ai`
- `publish-job` if extra validation is needed
- `send-notification-email` where applicable

## 17. Deployment Architecture

### Frontend
- GitLab repository
- GitLab CI/CD
- GitLab Pages
- HTTPS through GitLab Pages

### Backend
- Supabase free project

### AI
- Free-tier AI provider with zero-spend-safe behavior

### Environment variables
Frontend:
- public Supabase URL
- public anonymous key

Server-side only:
- service-role key
- AI provider token
- email provider secrets if used

Secrets are stored in Supabase/GitLab secret settings, never committed.

## 18. CI/CD

Pipeline stages:
1. Install dependencies
2. Lint
3. Type-check
4. Unit tests
5. Build
6. Deploy GitLab Pages on main branch

Database migrations and Edge Functions are version-controlled under `supabase/`.

Suggested repository structure:

```
job-portal/
  src/
  public/
  supabase/
    migrations/
    functions/
  tests/
  docs/
  .gitlab-ci.yml
  package.json
  vite.config.ts
```

## 19. Testing Strategy

### Unit tests
- Field parsing helpers
- Validation schemas
- Permission helpers
- Job filter logic
- Status transition rules

### Integration tests
- Candidate signup -> pending approval
- Admin approval -> candidate access
- Admin invite -> account activation
- AI parse -> structured draft
- Job publish -> candidate visibility
- Candidate Interested -> admin applicant visibility
- RLS denial cases

### End-to-end tests
- Candidate journey
- Admin journey
- Associate journey
- Super Admin journey

## 20. Error Handling

- Friendly UI errors for failed auth and permission checks.
- AI failure must preserve raw JD and fall back to manual/fallback extraction.
- Duplicate Interest clicks must not create duplicates.
- Unauthorized API attempts must fail even if UI controls are bypassed.
- Network failures should support safe retry for idempotent operations.
- Closed/deleted jobs cannot accept new interests.

## 21. Zero-Cost Constraints

The deployed system must not require a paid custom domain, paid hosting, paid database, or paid SMS service.

Default production configuration:
- GitLab Pages free hostname
- Supabase free tier
- Free-tier AI provider
- Email-based authentication
- Mobile number stored but no SMS OTP

If any provider changes its free tier, the architecture must allow that provider to be swapped without redesigning the application.

## 22. UI / UX Direction

Design style:
- Modern professional job-board look
- Light-first with optional dark mode later
- Responsive desktop/tablet/mobile
- Strong search experience
- Clear status badges
- Minimal admin friction
- Accessible forms and keyboard navigation

Primary screens:
1. Landing/login/signup
2. Pending approval
3. Candidate job feed
4. Job details
5. Saved jobs
6. My applications
7. Candidate profile
8. Admin dashboard
9. User approvals
10. Admin/Associate management
11. Job list
12. AI Job Import
13. Job editor/preview
14. Applicant list
15. Application detail/status history
16. Notifications
17. Audit log
18. Settings

## 23. Full-Scope Features Included in First Complete Build

- Candidate self-registration
- Email verification
- Admin approval gate
- Super Admin, Admin, Associate, Candidate roles
- Email-based Admin/Associate invitations
- Role management
- Job CRUD
- Draft/publish/close/archive lifecycle
- AI JD import
- AI structured extraction
- Manual job form
- Category/skill/location metadata
- Search and advanced filters
- Saved jobs
- Interested/applications
- Application status tracking
- Candidate and admin dashboards
- In-app notifications
- Email notification hooks
- Audit logs
- RLS security
- Responsive UI
- CI/CD
- GitLab Pages deployment configuration
- Supabase migrations and functions
- Automated tests
- Setup/deployment documentation

## 24. Explicitly Deferred Unless a Free Provider Is Confirmed

- SMS OTP
- Paid WhatsApp messaging
- Paid custom domain
- Paid AI usage
- Paid transactional email beyond free provider quotas
- Video interviews
- Payroll/billing
- External ATS integrations requiring paid APIs

## 25. Acceptance Criteria

The system is considered complete when:
1. A candidate can register, verify email, remain blocked pending approval, and gain access after approval.
2. A Super Admin can invite an Admin/Associate by email and manage their role.
3. An authorized poster can paste a raw JD and receive an editable structured draft.
4. The draft can be published as a searchable/filterable job.
5. Candidates can save jobs and mark Interest exactly once per job.
6. Admins can view interested candidates and update statuses.
7. Candidates can see their own status history.
8. Unauthorized users cannot bypass role restrictions at the database/API layer.
9. The frontend builds and deploys through GitLab Pages.
10. The backend can run within zero-cost free-tier constraints.
11. Core flows are covered by automated tests.
12. Setup documentation allows a new owner to deploy the platform from scratch.
