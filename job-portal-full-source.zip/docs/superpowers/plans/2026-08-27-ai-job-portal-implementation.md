# AI Job Portal Full Build Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the complete zero-cost AI-assisted job portal defined in the approved design, including secure role-based access, admin invitations, candidate approval, AI JD parsing, job publishing/search, applications, notifications, audit logs, dashboards, tests, and GitLab Pages deployment.

**Architecture:** A React + TypeScript + Vite single-page application is hosted on GitLab Pages. Supabase provides PostgreSQL, Auth, Row Level Security, and Edge Functions for privileged operations; AI parsing is isolated behind a provider adapter so Cloudflare Workers AI can be used while preserving a deterministic local fallback and zero-spend portability.

**Tech Stack:** React, TypeScript, Vite, Tailwind CSS, React Router, TanStack Query, React Hook Form, Zod, Supabase JS, Supabase CLI, Deno Edge Functions, Vitest, Testing Library, Playwright, GitLab CI/CD.

**Spec:** `docs/superpowers/specs/2026-08-27-ai-job-portal-design.md`

## Global Constraints

- The deployed system must not require paid hosting, paid database, paid custom domain, paid SMS, or paid AI usage.
- Candidate authentication is email/password with email verification; mobile is stored in profile but no SMS OTP is required.
- Roles are `super_admin`, `admin`, `associate`, and `candidate`.
- AI output must always create an editable draft and must never auto-publish.
- Privileged secrets, Supabase service-role keys, and AI provider tokens must never be exposed in frontend code.
- Database/API authorization must be enforced with RLS and server-side functions, not only UI checks.
- Candidate interest creation must be idempotent with one row per `(job_id, candidate_id)`.
- Closed, archived, deleted, or unpublished jobs must reject new candidate interests.
- AI failures must preserve source text and return a usable fallback draft.
- All schema changes and Edge Functions live under `supabase/` and remain version-controlled.
- GitLab CI must lint, type-check, test, build, and deploy GitLab Pages from `main`.

---

## File Structure

```text
job-portal/
  .env.example
  .gitignore
  .gitlab-ci.yml
  index.html
  package.json
  tsconfig.json
  vite.config.ts
  playwright.config.ts
  src/
    main.tsx
    app/
      App.tsx
      router.tsx
      providers.tsx
    components/
      layout/
      ui/
    features/
      auth/
      admin/
      ai-import/
      applications/
      jobs/
      notifications/
      profile/
      taxonomy/
    lib/
      env.ts
      queryClient.ts
      supabase.ts
      permissions.ts
      dates.ts
    types/
      database.ts
      domain.ts
    test/
      setup.ts
  supabase/
    config.toml
    seed.sql
    migrations/
    functions/
      _shared/
      invite-admin/
      change-user-role/
      approve-user/
      parse-job-ai/
      publish-job/
      send-notification-email/
  tests/
    e2e/
  docs/
    setup.md
    deployment.md
    superpowers/
```

The plan intentionally keeps domain logic inside feature modules and keeps privileged behavior inside Edge Functions or SQL functions so UI files do not become authorization boundaries.

---

### Task 1: Frontend Foundation and Test Harness

**Files:**
- Create: `package.json`
- Create: `vite.config.ts`
- Create: `tsconfig.json`
- Create: `index.html`
- Create: `.gitignore`
- Create: `.env.example`
- Create: `src/main.tsx`
- Create: `src/app/App.tsx`
- Create: `src/app/providers.tsx`
- Create: `src/lib/env.ts`
- Create: `src/lib/queryClient.ts`
- Create: `src/test/setup.ts`
- Test: `src/app/App.test.tsx`

**Interfaces:**
- Produces: `App`, `AppProviders`, `env`, and `queryClient` used by all later frontend tasks.
- Consumes: none.

- [ ] **Step 1: Write the failing shell test**

```tsx
// src/app/App.test.tsx
import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { App } from './App'

describe('App', () => {
  it('renders the portal shell', () => {
    render(<App />)
    expect(screen.getByText(/job portal/i)).toBeInTheDocument()
  })
})
```

- [ ] **Step 2: Create package and test configuration, then verify the test fails**

```json
{
  "name": "ai-job-portal",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "eslint .",
    "typecheck": "tsc --noEmit",
    "test": "vitest run",
    "test:watch": "vitest",
    "test:e2e": "playwright test"
  },
  "dependencies": {
    "@hookform/resolvers": "latest",
    "@supabase/supabase-js": "latest",
    "@tanstack/react-query": "latest",
    "@tanstack/react-query-devtools": "latest",
    "clsx": "latest",
    "lucide-react": "latest",
    "react": "latest",
    "react-dom": "latest",
    "react-hook-form": "latest",
    "react-router-dom": "latest",
    "zod": "latest"
  },
  "devDependencies": {
    "@eslint/js": "latest",
    "@playwright/test": "latest",
    "@testing-library/jest-dom": "latest",
    "@testing-library/react": "latest",
    "@testing-library/user-event": "latest",
    "@types/react": "latest",
    "@types/react-dom": "latest",
    "@vitejs/plugin-react": "latest",
    "eslint": "latest",
    "eslint-plugin-react-hooks": "latest",
    "eslint-plugin-react-refresh": "latest",
    "jsdom": "latest",
    "typescript": "latest",
    "typescript-eslint": "latest",
    "vite": "latest",
    "vitest": "latest"
  }
}
```

Run:

```bash
npm install
npm test -- src/app/App.test.tsx
```

Expected: FAIL because `App` and/or its dependencies do not exist yet.

- [ ] **Step 3: Implement the minimal app shell and providers**

```tsx
// src/app/App.tsx
export function App() {
  return <main>AI Job Portal</main>
}
```

```tsx
// src/app/providers.tsx
import type { PropsWithChildren } from 'react'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClient } from '../lib/queryClient'

export function AppProviders({ children }: PropsWithChildren) {
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
}
```

```ts
// src/lib/queryClient.ts
import { QueryClient } from '@tanstack/react-query'

export const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30_000 } },
})
```

```ts
// src/lib/env.ts
import { z } from 'zod'

const schema = z.object({
  VITE_SUPABASE_URL: z.string().url(),
  VITE_SUPABASE_ANON_KEY: z.string().min(1),
})

export const env = schema.parse(import.meta.env)
```

- [ ] **Step 4: Run unit tests and build**

```bash
npm test -- src/app/App.test.tsx
npm run typecheck
npm run build
```

Expected: all commands PASS once `.env.local` contains valid development values or the build test supplies them.

- [ ] **Step 5: Commit foundation**

```bash
git add package.json package-lock.json vite.config.ts tsconfig.json index.html .gitignore .env.example src
git commit -m "chore: scaffold job portal frontend"
```

---

### Task 2: Supabase Schema, Enums, and Seed Taxonomy

**Files:**
- Create: `supabase/config.toml`
- Create: `supabase/migrations/202608270001_initial_schema.sql`
- Create: `supabase/seed.sql`
- Create: `src/types/domain.ts`
- Test: `supabase/tests/schema.sql`

**Interfaces:**
- Produces database enums and tables named in the approved spec.
- Produces TypeScript role/status unions consumed by auth, jobs, and applications.
- Consumes: none.

- [ ] **Step 1: Write schema assertions before the migration**

```sql
-- supabase/tests/schema.sql
select plan(6);
select has_table('public', 'profiles', 'profiles exists');
select has_table('public', 'jobs', 'jobs exists');
select has_table('public', 'candidate_interests', 'candidate_interests exists');
select has_table('public', 'notifications', 'notifications exists');
select has_table('public', 'audit_logs', 'audit_logs exists');
select has_table('public', 'ai_parse_runs', 'ai_parse_runs exists');
select * from finish();
```

- [ ] **Step 2: Run the local test and verify failure**

```bash
supabase start
supabase db reset
supabase test db
```

Expected: FAIL because the tables do not exist.

- [ ] **Step 3: Create enums and core tables**

The migration must define these exact enums:

```sql
create type public.app_role as enum ('super_admin','admin','associate','candidate');
create type public.approval_status as enum ('pending_approval','approved','rejected');
create type public.job_status as enum ('draft','pending_review','published','closed','archived');
create type public.work_mode as enum ('remote','hybrid','onsite');
create type public.employment_type as enum ('permanent','contract','internship','freelance','part_time');
create type public.interest_status as enum (
  'interested','profile_reviewed','profile_shared','shortlisted','interview',
  'selected','rejected','on_hold','closed','withdrawn'
);
```

The migration must create all spec tables and the interest uniqueness rule:

```sql
create unique index candidate_interests_job_candidate_uidx
  on public.candidate_interests(job_id, candidate_id);
```

The `jobs` table must use `deleted_at timestamptz` for soft deletion and must retain `source_text text` plus `ai_generated boolean not null default false`.

- [ ] **Step 4: Seed initial taxonomy**

`supabase/seed.sql` must insert the approved categories and base skills with idempotent `on conflict do nothing` statements. Categories must include `data-engineering`, `data-analytics`, `data-science`, `ai-ml`, `frontend-development`, `backend-development`, `full-stack-development`, `devops`, `cloud-engineering`, `cybersecurity`, `qa-testing`, `business-analysis`, `product`, `mobile-development`, `database-dba`, `erp-crm`, and `other`.

- [ ] **Step 5: Add frontend domain types**

```ts
// src/types/domain.ts
export type AppRole = 'super_admin' | 'admin' | 'associate' | 'candidate'
export type ApprovalStatus = 'pending_approval' | 'approved' | 'rejected'
export type JobStatus = 'draft' | 'pending_review' | 'published' | 'closed' | 'archived'
export type WorkMode = 'remote' | 'hybrid' | 'onsite'
export type EmploymentType = 'permanent' | 'contract' | 'internship' | 'freelance' | 'part_time'
export type InterestStatus =
  | 'interested' | 'profile_reviewed' | 'profile_shared' | 'shortlisted'
  | 'interview' | 'selected' | 'rejected' | 'on_hold' | 'closed' | 'withdrawn'
```

- [ ] **Step 6: Reset DB and rerun schema tests**

```bash
supabase db reset
supabase test db
```

Expected: PASS.

- [ ] **Step 7: Commit schema**

```bash
git add supabase src/types/domain.ts
git commit -m "feat: add core job portal schema"
```

---

### Task 3: RLS Helpers and Security Policies

**Files:**
- Create: `supabase/migrations/202608270002_rls.sql`
- Test: `supabase/tests/rls.sql`
- Create: `src/lib/permissions.ts`
- Test: `src/lib/permissions.test.ts`

**Interfaces:**
- Produces SQL helpers `public.current_app_role()`, `public.is_admin_like()`, and RLS policies.
- Produces frontend helper `can(role, action)` for presentation only; SQL remains authoritative.
- Consumes: `app_role`, profiles, jobs, interests, saved_jobs, notifications.

- [ ] **Step 1: Write failing permission tests**

```ts
// src/lib/permissions.test.ts
import { describe, expect, it } from 'vitest'
import { can } from './permissions'

describe('can', () => {
  it('allows super admin to manage roles', () => {
    expect(can('super_admin', 'roles.manage')).toBe(true)
  })

  it('denies candidate job publishing', () => {
    expect(can('candidate', 'jobs.publish')).toBe(false)
  })
})
```

- [ ] **Step 2: Run test to confirm failure**

```bash
npm test -- src/lib/permissions.test.ts
```

Expected: FAIL because `can` does not exist.

- [ ] **Step 3: Implement frontend capability map**

```ts
// src/lib/permissions.ts
import type { AppRole } from '../types/domain'

export type Permission =
  | 'roles.manage'
  | 'users.approve'
  | 'jobs.create'
  | 'jobs.publish'
  | 'jobs.manage_all'
  | 'applications.manage'
  | 'audit.read'

const map: Record<AppRole, ReadonlySet<Permission>> = {
  super_admin: new Set(['roles.manage','users.approve','jobs.create','jobs.publish','jobs.manage_all','applications.manage','audit.read']),
  admin: new Set(['users.approve','jobs.create','jobs.publish','jobs.manage_all','applications.manage','audit.read']),
  associate: new Set(['jobs.create']),
  candidate: new Set(),
}

export function can(role: AppRole, permission: Permission) {
  return map[role].has(permission)
}
```

- [ ] **Step 4: Write database RLS tests for denial and allowed access**

`supabase/tests/rls.sql` must verify at minimum:
- candidate can read only published, non-deleted jobs;
- candidate cannot update another profile;
- candidate can insert own saved job only;
- candidate cannot create interest for a closed job;
- associate can edit an owned or assigned job but not an unrelated job;
- admin can manage ordinary users but cannot mutate a super-admin role;
- anonymous users cannot read protected jobs.

- [ ] **Step 5: Implement helper functions and policies**

```sql
create or replace function public.current_app_role()
returns public.app_role
language sql
stable
security definer
set search_path = public
as $$
  select ur.role
  from public.user_roles ur
  where ur.user_id = auth.uid()
  order by case ur.role
    when 'super_admin' then 1
    when 'admin' then 2
    when 'associate' then 3
    else 4 end
  limit 1;
$$;
```

All protected tables must have `alter table ... enable row level security;` and policies matching the approved spec.

- [ ] **Step 6: Run frontend and database permission tests**

```bash
npm test -- src/lib/permissions.test.ts
supabase db reset
supabase test db
```

Expected: PASS.

- [ ] **Step 7: Commit security layer**

```bash
git add supabase/migrations/202608270002_rls.sql supabase/tests/rls.sql src/lib/permissions.ts src/lib/permissions.test.ts
git commit -m "feat: enforce role based row level security"
```

---

### Task 4: Supabase Client, Session Model, and Candidate Registration

**Files:**
- Create: `src/lib/supabase.ts`
- Create: `src/features/auth/authApi.ts`
- Create: `src/features/auth/authSchemas.ts`
- Create: `src/features/auth/useSessionProfile.ts`
- Create: `src/features/auth/SignupPage.tsx`
- Create: `src/features/auth/LoginPage.tsx`
- Create: `src/features/auth/PendingApprovalPage.tsx`
- Test: `src/features/auth/authSchemas.test.ts`
- Create: `supabase/migrations/202608270003_auth_profile_trigger.sql`
- Test: `supabase/tests/auth_profile.sql`

**Interfaces:**
- Produces `signUpCandidate`, `signIn`, `signOut`, and `useSessionProfile`.
- Produces automatic `profiles` + `candidate` role creation for self-signup.
- Consumes: Supabase environment, profiles/user_roles tables.

- [ ] **Step 1: Write validation tests**

```ts
import { describe, expect, it } from 'vitest'
import { signupSchema } from './authSchemas'

describe('signupSchema', () => {
  it('requires name, valid email, mobile, and a strong password', () => {
    const result = signupSchema.safeParse({ fullName: '', email: 'x', mobile: '', password: '123' })
    expect(result.success).toBe(false)
  })
})
```

- [ ] **Step 2: Run test and confirm failure**

```bash
npm test -- src/features/auth/authSchemas.test.ts
```

Expected: FAIL because schema is absent.

- [ ] **Step 3: Implement schema and auth API**

```ts
export const signupSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email(),
  mobile: z.string().trim().min(8).max(20),
  password: z.string().min(8).max(128),
})
```

`signUpCandidate` must call `supabase.auth.signUp` with metadata `{ full_name, mobile }` and redirect candidates to email verification / pending approval states.

- [ ] **Step 4: Implement the auth profile trigger**

The migration must create a `security definer` trigger function on `auth.users` that inserts a profile with `pending_approval` and adds a `candidate` role only for ordinary self-signups. Invited admin/associate users are assigned their role by the invitation flow instead of being trusted from client metadata.

- [ ] **Step 5: Build Login, Signup, and Pending Approval pages**

The Signup form uses React Hook Form + Zod. The Login page routes approved users to their role dashboard and routes `pending_approval` candidates to `/pending-approval`.

- [ ] **Step 6: Run auth tests**

```bash
npm test -- src/features/auth/authSchemas.test.ts
supabase db reset
supabase test db
```

Expected: PASS.

- [ ] **Step 7: Commit candidate auth flow**

```bash
git add src/lib/supabase.ts src/features/auth supabase/migrations/202608270003_auth_profile_trigger.sql supabase/tests/auth_profile.sql
git commit -m "feat: add candidate registration and approval gate"
```

---

### Task 5: Bootstrap Super Admin and Admin/Associate Invitation

**Files:**
- Create: `supabase/functions/_shared/auth.ts`
- Create: `supabase/functions/_shared/cors.ts`
- Create: `supabase/functions/invite-admin/index.ts`
- Create: `supabase/functions/change-user-role/index.ts`
- Create: `src/features/admin/adminApi.ts`
- Create: `src/features/admin/AdminManagementPage.tsx`
- Test: `supabase/functions/invite-admin/index.test.ts`
- Test: `src/features/admin/AdminManagementPage.test.tsx`
- Create: `docs/setup.md`

**Interfaces:**
- Produces Edge Function request `{ email, fullName, role }` where role is `admin | associate`.
- Produces `inviteBackofficeUser()` frontend function.
- Consumes: service-role key server-side, authenticated super-admin JWT, user_roles table.

- [ ] **Step 1: Write Edge Function authorization test**

The test must assert a candidate JWT receives HTTP `403` and a super-admin JWT can reach invitation validation.

- [ ] **Step 2: Implement shared server authentication**

```ts
export async function requireRole(req: Request, allowed: AppRole[]) {
  const token = req.headers.get('Authorization')?.replace('Bearer ', '')
  if (!token) throw new HttpError(401, 'Missing bearer token')
  // Resolve user with anon client + supplied JWT, then query authoritative user_roles.
  // Reject when no allowed role is present.
}
```

The actual implementation must use server-owned environment secrets and must not trust a role supplied in the request body.

- [ ] **Step 3: Implement `invite-admin`**

Behavior:
1. require `super_admin`;
2. validate request with Zod-compatible server validation;
3. call `auth.admin.inviteUserByEmail`;
4. upsert profile name/email;
5. assign requested `admin` or `associate` role;
6. create `admin_invitations` row;
7. write `audit_logs` row `admin.invited`;
8. return `{ invitationId, userId, role }`.

- [ ] **Step 4: Implement `change-user-role`**

Rules:
- only super admin can assign/revoke admin roles;
- no caller may remove the final active super admin;
- role changes create `role.changed` audit records.

- [ ] **Step 5: Implement Admin Management UI**

The page lists current admins/associates, pending invitations, invite form, disable/enable controls, and role change controls. The client calls Edge Functions through `supabase.functions.invoke`.

- [ ] **Step 6: Document first super-admin bootstrap**

`docs/setup.md` must include exact Supabase CLI/SQL steps to create the first auth user and assign `super_admin` server-side. The procedure must never place a service-role key in browser code.

- [ ] **Step 7: Run tests and commit**

```bash
npm test -- src/features/admin/AdminManagementPage.test.tsx
supabase functions serve invite-admin --env-file supabase/.env.local
# run Deno tests for invite-admin and change-user-role
git add supabase/functions src/features/admin docs/setup.md
git commit -m "feat: add secure admin invitation and role management"
```

---

### Task 6: Candidate Approval and User Administration

**Files:**
- Create: `supabase/functions/approve-user/index.ts`
- Create: `src/features/admin/UserApprovalsPage.tsx`
- Create: `src/features/admin/usersApi.ts`
- Test: `src/features/admin/UserApprovalsPage.test.tsx`
- Test: `supabase/functions/approve-user/index.test.ts`

**Interfaces:**
- Produces request `{ userId, decision: 'approved' | 'rejected' | 'blocked' }`.
- Produces `listPendingUsers()` and `approveUser()`.
- Consumes: profiles, notifications, audit_logs.

- [ ] **Step 1: Write tests for approval state transitions**

Tests must verify:
- admin can approve/reject candidates;
- associate cannot approve users;
- approval writes `approved_by` and `approved_at`;
- blocked user receives no protected access;
- approval writes an in-app notification and audit log.

- [ ] **Step 2: Implement `approve-user` Edge Function**

The function authorizes `admin` or `super_admin`, validates target role is candidate, updates profile approval/block fields transactionally, inserts audit log, and inserts notification.

- [ ] **Step 3: Implement pending-user query and table UI**

The table must support search by name/email/mobile, status filter, and Approve/Reject/Block actions with confirmation dialogs.

- [ ] **Step 4: Run tests and commit**

```bash
npm test -- src/features/admin/UserApprovalsPage.test.tsx
git add supabase/functions/approve-user src/features/admin
git commit -m "feat: add candidate approval administration"
```

---

### Task 7: Taxonomy Management and Job Validation Model

**Files:**
- Create: `src/features/jobs/jobSchemas.ts`
- Create: `src/features/jobs/jobTypes.ts`
- Create: `src/features/taxonomy/taxonomyApi.ts`
- Create: `src/features/admin/TaxonomyPage.tsx`
- Test: `src/features/jobs/jobSchemas.test.ts`
- Create: `supabase/migrations/202608270004_taxonomy_permissions.sql`

**Interfaces:**
- Produces `jobDraftSchema`, `JobDraftInput`, taxonomy CRUD API.
- Consumes: seeded categories/skills/locations and RLS admin rules.

- [ ] **Step 1: Write job schema tests**

Tests must confirm:
- title required;
- max experience cannot be lower than min experience;
- hybrid/onsite jobs require at least one location;
- unknown salary is valid as blank;
- AI draft may retain blank ambiguous optional values.

- [ ] **Step 2: Implement job draft schema**

```ts
export const jobDraftSchema = z.object({
  title: z.string().trim().min(2).max(160),
  companyName: z.string().trim().max(160).nullable(),
  clientName: z.string().trim().max(160).nullable(),
  categoryId: z.string().uuid().nullable(),
  shortSummary: z.string().trim().max(320),
  description: z.string().trim().min(20),
  durationText: z.string().trim().max(120).nullable(),
  durationMonths: z.number().int().positive().max(120).nullable(),
  experienceMinYears: z.number().min(0).max(50).nullable(),
  experienceMaxYears: z.number().min(0).max(50).nullable(),
  employmentType: z.enum(['permanent','contract','internship','freelance','part_time']),
  workMode: z.enum(['remote','hybrid','onsite']),
  salaryText: z.string().trim().max(120).nullable(),
  locations: z.array(z.string().min(1)),
  mandatorySkills: z.array(z.string().min(1)),
  preferredSkills: z.array(z.string().min(1)),
  keywords: z.array(z.string().min(1)),
  closesAt: z.string().datetime().nullable(),
}).superRefine((value, ctx) => {
  if (value.experienceMinYears != null && value.experienceMaxYears != null && value.experienceMaxYears < value.experienceMinYears) {
    ctx.addIssue({ code: 'custom', path: ['experienceMaxYears'], message: 'Maximum experience must be greater than or equal to minimum experience' })
  }
})
```

- [ ] **Step 3: Implement taxonomy management**

Admins and super admins can create/rename/deactivate categories, skills, and locations. Historical job references remain valid when taxonomy rows are deactivated.

- [ ] **Step 4: Run tests and commit**

```bash
npm test -- src/features/jobs/jobSchemas.test.ts
git add src/features/jobs src/features/taxonomy src/features/admin/TaxonomyPage.tsx supabase/migrations/202608270004_taxonomy_permissions.sql
git commit -m "feat: add job taxonomy and validation"
```

---

### Task 8: Deterministic JD Fallback Parser

**Files:**
- Create: `src/features/ai-import/fallbackParser.ts`
- Create: `src/features/ai-import/aiTypes.ts`
- Test: `src/features/ai-import/fallbackParser.test.ts`

**Interfaces:**
- Produces `parseJobFallback(rawText: string): ParsedJobDraft`.
- `ParsedJobDraft` contains fields from the AI output contract plus `fieldConfidence` and `fallbackUsed`.
- Consumes: job draft schema conventions.

- [ ] **Step 1: Write parser tests using realistic recruiter text**

```ts
const raw = `Urgent Data Engineer opening. 6 month contract, Gurgaon hybrid 2 days office. 7-9 years. Mandatory: Snowflake, Python, dbt, SQL. AWS good to have.`

expect(parseJobFallback(raw)).toMatchObject({
  title: 'Data Engineer',
  durationMonths: 6,
  experienceMinYears: 7,
  experienceMaxYears: 9,
  workMode: 'hybrid',
  mandatorySkills: expect.arrayContaining(['Snowflake','Python','dbt','SQL']),
  preferredSkills: expect.arrayContaining(['AWS']),
  fallbackUsed: true,
})
```

- [ ] **Step 2: Verify tests fail before implementation**

```bash
npm test -- src/features/ai-import/fallbackParser.test.ts
```

- [ ] **Step 3: Implement deterministic extraction**

The parser must cover:
- `7-9 years`, `7 to 9 yrs`, `7+ years`;
- `6 month`, `12 months`, `1 year contract`;
- remote/hybrid/onsite keywords;
- labeled mandatory / required / must-have sections;
- preferred / good-to-have / nice-to-have sections;
- common category title inference;
- locations after `location:`, `based in`, or city keywords from active taxonomy;
- no fabricated salary/company values.

- [ ] **Step 4: Run tests and commit**

```bash
npm test -- src/features/ai-import/fallbackParser.test.ts
git add src/features/ai-import
git commit -m "feat: add deterministic jd fallback parser"
```

---

### Task 9: AI Provider Adapter and `parse-job-ai` Edge Function

**Files:**
- Create: `supabase/functions/_shared/ai.ts`
- Create: `supabase/functions/_shared/job-schema.ts`
- Create: `supabase/functions/parse-job-ai/index.ts`
- Create: `src/features/ai-import/aiImportApi.ts`
- Test: `supabase/functions/parse-job-ai/index.test.ts`

**Interfaces:**
- Produces POST body `{ rawText: string }` and response `{ draft, provider, fallbackUsed, warnings }`.
- Produces provider interface `parseJob(rawText): Promise<ParsedJobDraft>`.
- Consumes: authorized admin/associate role, AI environment token, `ai_parse_runs` table.

- [ ] **Step 1: Write tests for successful AI, invalid JSON, quota failure, and unauthorized caller**

Expected behaviors:
- valid provider JSON is schema-validated and returned;
- invalid JSON triggers fallback;
- provider HTTP error triggers fallback;
- source text survives every failure path;
- candidate caller gets `403`;
- each run writes `ai_parse_runs` without secrets.

- [ ] **Step 2: Define the provider contract**

```ts
export interface JobAiProvider {
  name: string
  model: string
  parseJob(rawText: string): Promise<ParsedJobDraft>
}
```

- [ ] **Step 3: Implement Cloudflare-compatible provider request**

The prompt must explicitly require strict JSON, require `null`/empty arrays for unknown facts, distinguish mandatory versus preferred skills, and forbid invented salary/company/location values.

- [ ] **Step 4: Implement fallback branch inside the Edge Function**

The server must have its own deterministic fallback equivalent so parsing still works when the external provider is unavailable. The browser implementation from Task 8 is for fast local preview/testing; the Edge Function result is authoritative for stored AI parse runs.

- [ ] **Step 5: Record parse metadata**

Store `raw_text_hash`, provider, model, success, fallback_used, extracted_json, and a sanitized `error_summary` when present.

- [ ] **Step 6: Run tests and commit**

```bash
# run Deno tests for parse-job-ai
git add supabase/functions/_shared supabase/functions/parse-job-ai src/features/ai-import/aiImportApi.ts
git commit -m "feat: add ai jd parsing with zero cost fallback"
```

---

### Task 10: AI Import UI, Manual Editor, and Draft Persistence

**Files:**
- Create: `src/features/ai-import/AiImportPage.tsx`
- Create: `src/features/jobs/JobEditorPage.tsx`
- Create: `src/features/jobs/JobForm.tsx`
- Create: `src/features/jobs/jobsApi.ts`
- Create: `src/features/jobs/jobMappers.ts`
- Test: `src/features/ai-import/AiImportPage.test.tsx`
- Test: `src/features/jobs/JobForm.test.tsx`

**Interfaces:**
- Produces `createDraft`, `updateDraft`, `loadJob`, and editable `JobDraftInput` form.
- Consumes: AI parse endpoint, taxonomy, `jobDraftSchema`, jobs RLS.

- [ ] **Step 1: Write AI import UI test**

Test flow:
1. paste raw JD;
2. click `Generate Draft`;
3. mocked parse result populates fields;
4. warning banner shows low-confidence fields;
5. no publish happens automatically;
6. user can save draft.

- [ ] **Step 2: Write manual editor test**

Test validates error messages for invalid experience range and verifies skills/locations can be edited before save.

- [ ] **Step 3: Implement `jobsApi` draft operations**

```ts
export async function createDraft(input: JobDraftInput, source?: { rawText?: string; aiGenerated?: boolean })
export async function updateDraft(jobId: string, input: JobDraftInput)
export async function getJobForEdit(jobId: string)
```

All writes use authenticated Supabase queries and rely on RLS ownership/admin rules.

- [ ] **Step 4: Implement AI Import and Job Form pages**

The AI page must preserve raw source text even when parsing fails. It must show `AI result`, `Fallback result`, or `Manual review required` status explicitly.

- [ ] **Step 5: Run tests and commit**

```bash
npm test -- src/features/ai-import/AiImportPage.test.tsx src/features/jobs/JobForm.test.tsx
git add src/features/ai-import src/features/jobs
git commit -m "feat: add ai assisted job draft editor"
```

---

### Task 11: Job Publishing, Lifecycle Rules, and Audit Events

**Files:**
- Create: `supabase/functions/publish-job/index.ts`
- Create: `supabase/migrations/202608270005_job_lifecycle.sql`
- Create: `src/features/jobs/jobActions.ts`
- Test: `supabase/tests/job_lifecycle.sql`
- Test: `src/features/jobs/jobActions.test.ts`

**Interfaces:**
- Produces validated transitions: draft -> pending_review/published, pending_review -> published/draft, published -> closed, closed -> published, any non-deleted -> archived, soft delete.
- Consumes: job ownership, role, audit log.

- [ ] **Step 1: Write transition tests**

Tests must reject:
- candidate publish;
- associate publish without permission;
- publishing a job missing title/description/category requirements;
- reopening an archived/deleted job;
- interest creation after close.

- [ ] **Step 2: Implement lifecycle validation function**

Create a SQL or Edge Function transition guard that validates current state, requested state, actor role/permission, and required publish fields.

- [ ] **Step 3: Implement `publish-job` Edge Function**

Publishing must set `published_at` on first publish, keep `created_by`, preserve source text, and write `job.published` audit event.

- [ ] **Step 4: Implement frontend lifecycle actions**

`jobActions.ts` must expose `publishJob`, `closeJob`, `reopenJob`, `archiveJob`, and `softDeleteJob`, each invalidating relevant TanStack Query caches.

- [ ] **Step 5: Run tests and commit**

```bash
npm test -- src/features/jobs/jobActions.test.ts
supabase db reset
supabase test db
git add supabase/functions/publish-job supabase/migrations/202608270005_job_lifecycle.sql supabase/tests/job_lifecycle.sql src/features/jobs/jobActions.ts src/features/jobs/jobActions.test.ts
git commit -m "feat: enforce job publishing lifecycle"
```

---

### Task 12: Candidate Job Feed, Search, Filters, Details, and Saved Jobs

**Files:**
- Create: `src/features/jobs/JobFeedPage.tsx`
- Create: `src/features/jobs/JobDetailsPage.tsx`
- Create: `src/features/jobs/JobFilters.tsx`
- Create: `src/features/jobs/jobSearch.ts`
- Create: `src/features/jobs/savedJobsApi.ts`
- Create: `src/features/jobs/SavedJobsPage.tsx`
- Test: `src/features/jobs/jobSearch.test.ts`
- Test: `src/features/jobs/JobFeedPage.test.tsx`

**Interfaces:**
- Produces `searchJobs(filters)`, `saveJob(jobId)`, `unsaveJob(jobId)`.
- Consumes: published jobs view/query, taxonomy, saved_jobs RLS.

- [ ] **Step 1: Write filter serialization tests**

Tests cover keyword, category, skill, location, work mode, employment type, experience range, company, date posted, and duration.

- [ ] **Step 2: Implement typed filter model**

```ts
export type JobSearchFilters = {
  keyword?: string
  categoryIds?: string[]
  skillIds?: string[]
  locations?: string[]
  workModes?: WorkMode[]
  employmentTypes?: EmploymentType[]
  minExperience?: number
  maxExperience?: number
  company?: string
  postedWithinDays?: number
  durationMonths?: number
}
```

- [ ] **Step 3: Implement server-backed search**

Use Supabase query filters and PostgreSQL text search where practical; avoid downloading all jobs to filter in-browser. The result excludes non-published, deleted, closed, and archived jobs.

- [ ] **Step 4: Implement feed/detail/saved pages**

Job cards show title, company/client when present, location, work mode, experience, category, posted date, top skills, save action, and Interested action slot.

- [ ] **Step 5: Run tests and commit**

```bash
npm test -- src/features/jobs/jobSearch.test.ts src/features/jobs/JobFeedPage.test.tsx
git add src/features/jobs
git commit -m "feat: add candidate job discovery and saved jobs"
```

---

### Task 13: Candidate Interest/Application Workflow and Status History

**Files:**
- Create: `supabase/migrations/202608270006_interest_rpc.sql`
- Create: `src/features/applications/applicationsApi.ts`
- Create: `src/features/applications/MyApplicationsPage.tsx`
- Create: `src/features/applications/ApplicationTimeline.tsx`
- Test: `supabase/tests/interests.sql`
- Test: `src/features/applications/MyApplicationsPage.test.tsx`

**Interfaces:**
- Produces RPC `public.mark_interest(p_job_id uuid)` and `public.withdraw_interest(p_job_id uuid)`.
- Produces `markInterested`, `withdrawInterest`, `listMyApplications`.
- Consumes: candidate_interests, interest_status_history, published jobs.

- [ ] **Step 1: Write DB idempotency and eligibility tests**

Tests must verify:
- first click creates one row;
- second click returns the same interest rather than duplicating;
- unique index remains intact;
- closed/unpublished/deleted job rejects interest;
- candidate cannot create interest for another candidate;
- withdrawal sets status/history and is visible only to owner/admin scope.

- [ ] **Step 2: Implement `mark_interest` transactionally**

The RPC must use `auth.uid()`, validate candidate approval, validate job eligibility, insert on conflict safely, and append initial history only on first creation.

- [ ] **Step 3: Implement application API and candidate UI**

The My Applications page groups current status with a chronological history timeline and supports withdrawal when current status permits it.

- [ ] **Step 4: Run tests and commit**

```bash
supabase db reset
supabase test db
npm test -- src/features/applications/MyApplicationsPage.test.tsx
git add supabase/migrations/202608270006_interest_rpc.sql supabase/tests/interests.sql src/features/applications
git commit -m "feat: add candidate interest and application history"
```

---

### Task 14: Admin Applicant Management and Status Transitions

**Files:**
- Create: `supabase/migrations/202608270007_application_status.sql`
- Create: `src/features/applications/AdminApplicantsPage.tsx`
- Create: `src/features/applications/ApplicationDetailPage.tsx`
- Create: `src/features/applications/applicationStatus.ts`
- Test: `src/features/applications/applicationStatus.test.ts`
- Test: `supabase/tests/application_status.sql`

**Interfaces:**
- Produces `update_application_status(interest_id, next_status)`.
- Produces `allowedNextStatuses(currentStatus, role)`.
- Consumes: applicant scope, candidate_interests, history, notifications, audit logs.

- [ ] **Step 1: Write status transition unit tests**

Example expectations:
- `interested -> profile_reviewed` allowed;
- `selected -> interview` denied;
- `withdrawn -> shortlisted` denied;
- unauthorized associate cannot update unrelated job applicant.

- [ ] **Step 2: Implement transition map**

```ts
const transitions: Record<InterestStatus, InterestStatus[]> = {
  interested: ['profile_reviewed','profile_shared','shortlisted','rejected','on_hold','closed','withdrawn'],
  profile_reviewed: ['profile_shared','shortlisted','rejected','on_hold','closed'],
  profile_shared: ['shortlisted','interview','rejected','on_hold','closed'],
  shortlisted: ['interview','selected','rejected','on_hold','closed'],
  interview: ['selected','rejected','on_hold','closed'],
  selected: ['closed'],
  rejected: ['closed'],
  on_hold: ['profile_reviewed','profile_shared','shortlisted','interview','rejected','closed'],
  closed: [],
  withdrawn: [],
}
```

- [ ] **Step 3: Implement database transition function**

The function must enforce scope and transition rules, update current status, append `interest_status_history`, create candidate notification, and write `application.status_changed` audit record in one transaction.

- [ ] **Step 4: Implement admin applicant screens**

Admin list supports job filter, status filter, candidate search, and status update. Application Detail shows profile, job summary, current status, timeline, and audit-relevant actor/time metadata.

- [ ] **Step 5: Run tests and commit**

```bash
npm test -- src/features/applications/applicationStatus.test.ts
supabase db reset
supabase test db
git add supabase/migrations/202608270007_application_status.sql supabase/tests/application_status.sql src/features/applications
git commit -m "feat: add applicant management and status workflow"
```

---

### Task 15: Notifications and Audit Log UI

**Files:**
- Create: `src/features/notifications/notificationsApi.ts`
- Create: `src/features/notifications/NotificationsPage.tsx`
- Create: `src/features/notifications/NotificationBell.tsx`
- Create: `src/features/admin/AuditLogPage.tsx`
- Create: `src/features/admin/auditApi.ts`
- Create: `supabase/functions/send-notification-email/index.ts`
- Test: `src/features/notifications/NotificationsPage.test.tsx`

**Interfaces:**
- Produces notification list/read actions and read-only audit explorer.
- Consumes: notifications RLS, audit_logs RLS, free email provider hook when configured.

- [ ] **Step 1: Write notification UI test**

Tests verify unread count, mark-one-read, mark-all-read, and candidate isolation.

- [ ] **Step 2: Implement notification API and UI**

Queries return newest-first notifications. Candidate/admin users can mark only their own notifications as read.

- [ ] **Step 3: Implement audit log explorer**

Super Admin sees all audit events. Admin sees operational audit events permitted by policy. Filters include actor, action, entity type, and date range.

- [ ] **Step 4: Implement optional email hook**

`send-notification-email` must no-op successfully when no provider secret is configured, so zero-cost local and production deployments remain functional without email beyond Supabase auth mail.

- [ ] **Step 5: Run tests and commit**

```bash
npm test -- src/features/notifications/NotificationsPage.test.tsx
git add src/features/notifications src/features/admin/AuditLogPage.tsx src/features/admin/auditApi.ts supabase/functions/send-notification-email
git commit -m "feat: add notifications and audit log viewer"
```

---

### Task 16: Dashboards, Profile, and Platform Settings

**Files:**
- Create: `src/features/admin/AdminDashboardPage.tsx`
- Create: `src/features/admin/dashboardApi.ts`
- Create: `src/features/profile/ProfilePage.tsx`
- Create: `src/features/profile/profileApi.ts`
- Create: `src/features/admin/SettingsPage.tsx`
- Create: `src/features/admin/settingsApi.ts`
- Create: `supabase/migrations/202608270008_dashboard_views.sql`
- Test: `src/features/admin/AdminDashboardPage.test.tsx`

**Interfaces:**
- Produces KPI queries and editable allowed profile/settings fields.
- Consumes: jobs, profiles, applications, platform_settings.

- [ ] **Step 1: Write dashboard rendering test**

Mock KPI response and verify cards for total users, approved candidates, pending approvals, active/draft/closed jobs, total interests, interests today, status distribution, top categories, top skills, and jobs with most interest.

- [ ] **Step 2: Create efficient database views/RPCs**

Use aggregate views or RPCs to avoid multiple full-table scans from the browser. Restrict KPI access to admin-like roles.

- [ ] **Step 3: Implement profile page**

Candidate can update allowed fields such as full name and mobile. Email changes remain an Auth-controlled flow. Role, approval status, and blocked state are display-only for candidates.

- [ ] **Step 4: Implement platform settings page**

Super Admin can update portal display name, default pagination size, whether associates may publish, and whether candidate withdrawal is enabled. Values live in `platform_settings` and are RLS-protected.

- [ ] **Step 5: Run tests and commit**

```bash
npm test -- src/features/admin/AdminDashboardPage.test.tsx
git add src/features/admin src/features/profile supabase/migrations/202608270008_dashboard_views.sql
git commit -m "feat: add dashboards profiles and platform settings"
```

---

### Task 17: Routing, Guards, Layouts, and Full Responsive UX

**Files:**
- Create: `src/app/router.tsx`
- Create: `src/features/auth/ProtectedRoute.tsx`
- Create: `src/features/auth/RoleRoute.tsx`
- Create: `src/components/layout/PublicLayout.tsx`
- Create: `src/components/layout/CandidateLayout.tsx`
- Create: `src/components/layout/AdminLayout.tsx`
- Create: `src/components/ui/*`
- Modify: `src/app/App.tsx`
- Test: `src/features/auth/RoleRoute.test.tsx`

**Interfaces:**
- Produces route-level UX protection; database RLS remains authoritative.
- Consumes: session profile, permission map, all feature pages.

- [ ] **Step 1: Write route guard tests**

Tests verify:
- anonymous user redirected to login;
- pending candidate redirected to pending page;
- approved candidate denied admin route;
- admin gets admin dashboard;
- super admin gets admin management controls;
- associate sees only permitted back-office navigation.

- [ ] **Step 2: Implement route tree**

Routes must include all 18 primary screens from the approved design plus reset-password and not-found pages.

- [ ] **Step 3: Implement responsive layouts and shared UI primitives**

Provide accessible buttons, inputs, select/combobox, modal/dialog, badge, table, pagination, empty state, loading skeleton, error alert, mobile navigation, and desktop sidebar.

- [ ] **Step 4: Add keyboard/accessibility checks to component tests**

Use Testing Library role/name queries and ensure form inputs have labels, dialogs trap focus, and buttons have accessible names.

- [ ] **Step 5: Run tests and build**

```bash
npm test
npm run typecheck
npm run build
```

Expected: PASS.

- [ ] **Step 6: Commit full application routing and UX**

```bash
git add src/app src/components src/features/auth
git commit -m "feat: complete role based portal navigation"
```

---

### Task 18: End-to-End, RLS Regression, and Security Verification

**Files:**
- Create: `playwright.config.ts`
- Create: `tests/e2e/candidate.spec.ts`
- Create: `tests/e2e/admin.spec.ts`
- Create: `tests/e2e/associate.spec.ts`
- Create: `tests/e2e/super-admin.spec.ts`
- Create: `tests/e2e/ai-import.spec.ts`
- Create: `tests/e2e/helpers/auth.ts`
- Create: `tests/e2e/helpers/db.ts`

**Interfaces:**
- Produces release-gate E2E coverage for the acceptance criteria.
- Consumes: running frontend and local Supabase stack.

- [ ] **Step 1: Configure Playwright against local stack**

`playwright.config.ts` launches Vite against local Supabase test environment and uses isolated seeded test accounts.

- [ ] **Step 2: Implement candidate journey test**

Test exact sequence:
1. sign up;
2. confirm pending state;
3. admin approves via seeded admin context;
4. candidate logs in;
5. searches a published job;
6. saves it;
7. clicks Interested twice;
8. confirms only one application exists;
9. views status history.

- [ ] **Step 3: Implement admin journey test**

Test invite back-office user, approve candidate, create AI draft, edit it, publish job, inspect applicants, and change status.

- [ ] **Step 4: Implement associate scope test**

Verify associate can edit owned/assigned jobs but receives database denial for unrelated job mutations.

- [ ] **Step 5: Implement super-admin test**

Verify admin creation, role changes, taxonomy/settings access, and audit log visibility.

- [ ] **Step 6: Implement AI fallback E2E**

Force provider failure and verify a fallback draft is still editable and publishable after review.

- [ ] **Step 7: Run all release tests**

```bash
npm test
npm run typecheck
npm run build
npm run test:e2e
supabase test db
```

Expected: PASS.

- [ ] **Step 8: Commit release tests**

```bash
git add playwright.config.ts tests
git commit -m "test: cover complete portal journeys"
```

---

### Task 19: GitLab CI/CD and GitLab Pages Deployment

**Files:**
- Create: `.gitlab-ci.yml`
- Modify: `vite.config.ts`
- Create: `docs/deployment.md`
- Modify: `.env.example`

**Interfaces:**
- Produces CI pipeline `test -> build -> pages` and documented Supabase/AI secret setup.
- Consumes: complete application and test suite.

- [ ] **Step 1: Configure Vite base path from GitLab project slug**

```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: process.env.CI_PROJECT_NAME ? `/${process.env.CI_PROJECT_NAME}/` : '/',
})
```

- [ ] **Step 2: Create CI jobs**

```yaml
stages:
  - verify
  - build
  - deploy

verify:
  image: node:24-alpine
  stage: verify
  script:
    - npm ci
    - npm run lint
    - npm run typecheck
    - npm test

build:
  image: node:24-alpine
  stage: build
  script:
    - npm ci
    - npm run build
  artifacts:
    paths:
      - dist

pages:
  image: alpine:latest
  stage: deploy
  needs: [build]
  script:
    - mv dist public
  artifacts:
    paths:
      - public
  rules:
    - if: '$CI_COMMIT_BRANCH == "main"'
```

If the repository default branch remains `master`, change the final rule to `master` before first GitLab deployment; the deployment document must state this explicitly.

- [ ] **Step 3: Document deployment from scratch**

`docs/deployment.md` must include:
- create Supabase project;
- configure Auth redirect URLs for GitLab Pages;
- run migrations and seed;
- deploy Edge Functions;
- set server secrets;
- configure frontend GitLab CI variables;
- bootstrap first super admin;
- configure Cloudflare AI token or leave AI provider disabled to use fallback parser;
- push to GitLab and confirm Pages URL;
- smoke-test signup, approval, AI import, publish, search, and Interest.

- [ ] **Step 4: Validate CI config and local production build**

```bash
npm ci
npm run lint
npm run typecheck
npm test
npm run build
```

Expected: PASS.

- [ ] **Step 5: Commit deployment configuration**

```bash
git add .gitlab-ci.yml vite.config.ts docs/deployment.md .env.example
git commit -m "ci: deploy job portal with gitlab pages"
```

---

### Task 20: Final Acceptance Verification and Handoff

**Files:**
- Create: `docs/acceptance-checklist.md`
- Modify: `README.md`

**Interfaces:**
- Produces a reproducible handoff and verification record.
- Consumes: all prior tasks.

- [ ] **Step 1: Create acceptance checklist matching all 12 spec criteria**

The checklist must include evidence columns for test command, manual verification, and result for each acceptance criterion.

- [ ] **Step 2: Create README with operator-first instructions**

README must contain:
- product overview;
- architecture diagram in Mermaid;
- local setup;
- environment variables by frontend/server scope;
- Supabase reset/start commands;
- test commands;
- GitLab deployment summary;
- role matrix;
- zero-cost constraints and provider-swap note.

- [ ] **Step 3: Run the complete verification suite from a clean install**

```bash
rm -rf node_modules dist
npm ci
npm run lint
npm run typecheck
npm test
npm run build
supabase db reset
supabase test db
npm run test:e2e
```

Expected: every command exits `0`.

- [ ] **Step 4: Confirm no secrets are committed**

```bash
git grep -nE '(service_role|SUPABASE_SERVICE_ROLE_KEY|CLOUDFLARE_API_TOKEN|BEGIN PRIVATE KEY)' -- ':!docs/*'
```

Expected: no real credential values.

- [ ] **Step 5: Confirm working tree and history**

```bash
git status --short
git log --oneline --decorate -20
```

Expected: clean working tree and incremental task commits.

- [ ] **Step 6: Commit handoff documentation**

```bash
git add README.md docs/acceptance-checklist.md
git commit -m "docs: complete job portal deployment handoff"
```

---

## Execution Order and Dependency Notes

- Tasks 1-3 establish the application and database security foundation.
- Tasks 4-6 complete identity, approval, and back-office administration.
- Tasks 7-11 complete job modeling, AI import, editing, and lifecycle.
- Tasks 12-14 complete candidate discovery and end-to-end recruitment workflow.
- Tasks 15-17 complete notifications, dashboards, settings, routing, and UX.
- Tasks 18-20 are release gates: E2E, deployment, security, acceptance, and handoff.
- No task may weaken RLS to make UI development easier; test fixtures must authenticate with realistic roles instead.
- The AI provider remains replaceable through `JobAiProvider`; no Cloudflare-specific response shape may leak into UI domain types.

## Spec Coverage Self-Review

- Roles, registration, email verification, approval, admin invitations: Tasks 4-6.
- RLS/server-side authorization: Tasks 2-6, 11, 13, 14, 18.
- AI extraction, strict draft review, fallback parser: Tasks 8-10.
- Job taxonomy, CRUD, lifecycle, publish/close/archive/delete: Tasks 7, 10, 11.
- Search/filtering, saved jobs, job details: Task 12.
- Interested/idempotency/status history: Tasks 13-14.
- Notifications/email hook/audit logs: Task 15 plus mutation tasks.
- Dashboards/profile/settings: Task 16.
- Responsive role-based screens: Task 17.
- CI/CD/GitLab Pages/Supabase deployment: Task 19.
- Automated tests and all acceptance criteria: Tasks 18 and 20.
- Zero-cost/provider swap constraints: Global Constraints, Tasks 9, 15, 19, 20.

## Placeholder and Type Consistency Self-Review

- The plan contains no implementation placeholders.
- Role, job status, work mode, employment type, and interest status names match the approved spec.
- `JobAiProvider`, `JobDraftInput`, `ParsedJobDraft`, and `JobSearchFilters` have one named contract each and are consumed consistently.
- Candidate Interest uses `(job_id, candidate_id)` uniqueness and `auth.uid()` server authority throughout.
- Admin invitation and role mutation never trust browser-supplied privilege claims.
