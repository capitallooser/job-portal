# TalentBridge — AI-Assisted Private Job Portal

A complete role-controlled job portal designed to run on free tiers: GitLab Pages + Supabase + optional Cloudflare Workers AI. Candidates self-register and wait for approval; Super Admins invite back-office users; Admins/Associates paste a raw JD, receive an editable structured draft, and publish searchable jobs.

```mermaid
flowchart LR
  Browser[React + Vite\nGitLab Pages] --> Auth[Supabase Auth]
  Browser --> DB[(Supabase PostgreSQL + RLS)]
  Browser --> Edge[Supabase Edge Functions]
  Edge --> DB
  Edge --> AI[Optional Cloudflare Workers AI]
  AI -. provider unavailable .-> Fallback[Deterministic JD Parser]
  Fallback --> Edge
```

## Roles
| Role | Main access |
|---|---|
| Super Admin | Full governance, Admin/Associate invitations, roles, settings, taxonomy, audit, all jobs/applications |
| Admin | Candidate approvals, job lifecycle, applications, taxonomy, audit |
| Associate | AI/manual job creation, own/assigned jobs, scoped applicants; publish depends on setting |
| Candidate | Approved job search, saved jobs, Interest, application history, profile, notifications |

## Core features
- Email/password signup, email verification and admin approval gate.
- Email invitations for Admins and Associates.
- AI JD Import with deterministic zero-cost fallback and mandatory review-before-publish.
- Job draft/pending/published/closed/archived lifecycle, duplicate/unpublish/soft-delete.
- Keyword/category/location/skill/work-mode/type/experience/date filters.
- Saved jobs and idempotent Interested action.
- Full candidate status pipeline and immutable status history.
- In-app notifications, audit logging, dashboards, taxonomy and platform settings.
- PostgreSQL RLS plus column-level privilege hardening; frontend role checks are never the security boundary.
- Responsive candidate/admin interfaces and GitLab Pages hash routing.

## Local setup
```bash
cp .env.example .env.local
npm install
npm run dev
```
Set the public Supabase URL and anon/publishable key in `.env.local`. For a full local backend, install Docker + Supabase CLI:
```bash
supabase start
supabase db reset
supabase test db
```

## Verification
```bash
npm run lint
npm run typecheck
npm test
npm run build
npm run test:e2e   # requires RUN_E2E=1 + seeded role accounts for actual journeys
```

## Environment scope
**Browser-safe:** `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_APP_NAME`.

**Server-only:** Cloudflare account/token/model and any optional email-provider settings. Store server secrets with `supabase secrets set`; never prefix privileged secrets with `VITE_`.

## Deployment
See `docs/deployment.md` for Supabase migrations/functions, first Super Admin bootstrap, GitLab variables and Pages deployment.

## Zero-cost constraint
No paid domain, SMS, hosting, database, or AI service is required. Mobile is collected as profile data without SMS OTP. AI can be disabled entirely and the fallback parser still creates editable job drafts. Free-tier quotas and mail-provider limits are operational constraints; swap providers through the isolated Edge Function adapter without changing candidate/job data models.
